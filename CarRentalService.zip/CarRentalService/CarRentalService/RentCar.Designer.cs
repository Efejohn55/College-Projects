﻿
namespace CarRentalService
{
    partial class RentCar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RentCar));
            this.GoBacktoMain = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.customernameIbl = new System.Windows.Forms.Label();
            this.DriversLicenseIbl = new System.Windows.Forms.Label();
            this.insuranceIbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.FirstNametxt = new System.Windows.Forms.TextBox();
            this.LastNametxt = new System.Windows.Forms.TextBox();
            this.PhoneNumbertxt = new System.Windows.Forms.TextBox();
            this.DriversLicensetxt = new System.Windows.Forms.TextBox();
            this.InsuranceCompanytxt = new System.Windows.Forms.TextBox();
            this.DateOfBirthtxt = new System.Windows.Forms.TextBox();
            this.Addresstxt = new System.Windows.Forms.TextBox();
            this.DaysRentedtxt = new System.Windows.Forms.TextBox();
            this.rentingoutIbl = new System.Windows.Forms.Label();
            this.ReturnCar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.DamagesOccuredtxt = new System.Windows.Forms.TextBox();
            this.RentOut = new System.Windows.Forms.Button();
            this.carnotavailableIbl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.ReturnIbl = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.milagedriventxt = new System.Windows.Forms.TextBox();
            this.milageDrivenIbl = new System.Windows.Forms.Label();
            this.CarInventoryDataGridView = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.CarInventoryDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // GoBacktoMain
            // 
            this.GoBacktoMain.Location = new System.Drawing.Point(1068, 473);
            this.GoBacktoMain.Name = "GoBacktoMain";
            this.GoBacktoMain.Size = new System.Drawing.Size(130, 52);
            this.GoBacktoMain.TabIndex = 0;
            this.GoBacktoMain.Text = "Back to Home Page";
            this.GoBacktoMain.UseVisualStyleBackColor = true;
            this.GoBacktoMain.Click += new System.EventHandler(this.GoBacktoMain_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(1204, 473);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(119, 52);
            this.Exit.TabIndex = 1;
            this.Exit.Text = "Completely exit program";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // customernameIbl
            // 
            this.customernameIbl.AutoSize = true;
            this.customernameIbl.Location = new System.Drawing.Point(3, 30);
            this.customernameIbl.Name = "customernameIbl";
            this.customernameIbl.Size = new System.Drawing.Size(144, 17);
            this.customernameIbl.TabIndex = 2;
            this.customernameIbl.Text = "Customer First Name:";
            // 
            // DriversLicenseIbl
            // 
            this.DriversLicenseIbl.AutoSize = true;
            this.DriversLicenseIbl.Location = new System.Drawing.Point(3, 115);
            this.DriversLicenseIbl.Name = "DriversLicenseIbl";
            this.DriversLicenseIbl.Size = new System.Drawing.Size(126, 17);
            this.DriversLicenseIbl.TabIndex = 3;
            this.DriversLicenseIbl.Text = "Drivers Id Number:";
            // 
            // insuranceIbl
            // 
            this.insuranceIbl.AutoSize = true;
            this.insuranceIbl.Location = new System.Drawing.Point(11, 141);
            this.insuranceIbl.Name = "insuranceIbl";
            this.insuranceIbl.Size = new System.Drawing.Size(148, 17);
            this.insuranceIbl.TabIndex = 4;
            this.insuranceIbl.Text = "Insurance information:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 17);
            this.label1.TabIndex = 5;
            this.label1.Text = "Customer Last Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Phone Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 181);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(94, 17);
            this.label3.TabIndex = 7;
            this.label3.Text = "Date Of Birth:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 211);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 17);
            this.label4.TabIndex = 8;
            this.label4.Text = "Address Location:";
            // 
            // FirstNametxt
            // 
            this.FirstNametxt.Location = new System.Drawing.Point(165, 30);
            this.FirstNametxt.Name = "FirstNametxt";
            this.FirstNametxt.Size = new System.Drawing.Size(100, 22);
            this.FirstNametxt.TabIndex = 9;
            // 
            // LastNametxt
            // 
            this.LastNametxt.Location = new System.Drawing.Point(168, 58);
            this.LastNametxt.Name = "LastNametxt";
            this.LastNametxt.Size = new System.Drawing.Size(100, 22);
            this.LastNametxt.TabIndex = 10;
            // 
            // PhoneNumbertxt
            // 
            this.PhoneNumbertxt.Location = new System.Drawing.Point(168, 86);
            this.PhoneNumbertxt.Name = "PhoneNumbertxt";
            this.PhoneNumbertxt.Size = new System.Drawing.Size(100, 22);
            this.PhoneNumbertxt.TabIndex = 11;
            // 
            // DriversLicensetxt
            // 
            this.DriversLicensetxt.Location = new System.Drawing.Point(165, 114);
            this.DriversLicensetxt.Name = "DriversLicensetxt";
            this.DriversLicensetxt.Size = new System.Drawing.Size(100, 22);
            this.DriversLicensetxt.TabIndex = 12;
            // 
            // InsuranceCompanytxt
            // 
            this.InsuranceCompanytxt.Location = new System.Drawing.Point(165, 141);
            this.InsuranceCompanytxt.Name = "InsuranceCompanytxt";
            this.InsuranceCompanytxt.Size = new System.Drawing.Size(100, 22);
            this.InsuranceCompanytxt.TabIndex = 13;
            // 
            // DateOfBirthtxt
            // 
            this.DateOfBirthtxt.Location = new System.Drawing.Point(165, 178);
            this.DateOfBirthtxt.Name = "DateOfBirthtxt";
            this.DateOfBirthtxt.Size = new System.Drawing.Size(100, 22);
            this.DateOfBirthtxt.TabIndex = 14;
            // 
            // Addresstxt
            // 
            this.Addresstxt.Location = new System.Drawing.Point(165, 211);
            this.Addresstxt.Name = "Addresstxt";
            this.Addresstxt.Size = new System.Drawing.Size(100, 22);
            this.Addresstxt.TabIndex = 15;
            // 
            // DaysRentedtxt
            // 
            this.DaysRentedtxt.Location = new System.Drawing.Point(165, 245);
            this.DaysRentedtxt.Name = "DaysRentedtxt";
            this.DaysRentedtxt.Size = new System.Drawing.Size(100, 22);
            this.DaysRentedtxt.TabIndex = 26;
            // 
            // rentingoutIbl
            // 
            this.rentingoutIbl.AutoSize = true;
            this.rentingoutIbl.Location = new System.Drawing.Point(13, 231);
            this.rentingoutIbl.Name = "rentingoutIbl";
            this.rentingoutIbl.Size = new System.Drawing.Size(116, 68);
            this.rentingoutIbl.TabIndex = 27;
            this.rentingoutIbl.Text = "Days renting out/\r\nrented out:\r\n\r\n\r\n";
            // 
            // ReturnCar
            // 
            this.ReturnCar.Location = new System.Drawing.Point(34, 515);
            this.ReturnCar.Name = "ReturnCar";
            this.ReturnCar.Size = new System.Drawing.Size(100, 37);
            this.ReturnCar.TabIndex = 30;
            this.ReturnCar.Text = "Return Car";
            this.ReturnCar.UseVisualStyleBackColor = true;
            this.ReturnCar.Click += new System.EventHandler(this.ReturnCar_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(179, 515);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(193, 68);
            this.label5.TabIndex = 31;
            this.label5.Text = "Any Damages occured on\r\n vehicle while renting, please \r\ninput here in this textb" +
    "ox\r\n\r\n";
            // 
            // DamagesOccuredtxt
            // 
            this.DamagesOccuredtxt.Location = new System.Drawing.Point(380, 542);
            this.DamagesOccuredtxt.Name = "DamagesOccuredtxt";
            this.DamagesOccuredtxt.Size = new System.Drawing.Size(100, 22);
            this.DamagesOccuredtxt.TabIndex = 32;
            // 
            // RentOut
            // 
            this.RentOut.Location = new System.Drawing.Point(1126, 358);
            this.RentOut.Name = "RentOut";
            this.RentOut.Size = new System.Drawing.Size(153, 46);
            this.RentOut.TabIndex = 33;
            this.RentOut.Text = "Rent Out Car";
            this.RentOut.UseVisualStyleBackColor = true;
            this.RentOut.Click += new System.EventHandler(this.RentOut_Click);
            // 
            // carnotavailableIbl
            // 
            this.carnotavailableIbl.AutoSize = true;
            this.carnotavailableIbl.Location = new System.Drawing.Point(472, 364);
            this.carnotavailableIbl.Name = "carnotavailableIbl";
            this.carnotavailableIbl.Size = new System.Drawing.Size(8, 17);
            this.carnotavailableIbl.TabIndex = 34;
            this.carnotavailableIbl.Text = "\r\n";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(3, 299);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(470, 136);
            this.label6.TabIndex = 35;
            this.label6.Text = resources.GetString("label6.Text");
            // 
            // ReturnIbl
            // 
            this.ReturnIbl.AutoSize = true;
            this.ReturnIbl.Location = new System.Drawing.Point(15, 482);
            this.ReturnIbl.Name = "ReturnIbl";
            this.ReturnIbl.Size = new System.Drawing.Size(132, 17);
            this.ReturnIbl.TabIndex = 36;
            this.ReturnIbl.Text = "Return Car Section:\r\n";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(377, 33);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 34);
            this.label7.TabIndex = 37;
            this.label7.Text = "Car Inventory \r\ndatagrid:\r\n";
            // 
            // milagedriventxt
            // 
            this.milagedriventxt.Location = new System.Drawing.Point(346, 473);
            this.milagedriventxt.Name = "milagedriventxt";
            this.milagedriventxt.Size = new System.Drawing.Size(100, 22);
            this.milagedriventxt.TabIndex = 38;
            // 
            // milageDrivenIbl
            // 
            this.milageDrivenIbl.AutoSize = true;
            this.milageDrivenIbl.Location = new System.Drawing.Point(179, 465);
            this.milageDrivenIbl.Name = "milageDrivenIbl";
            this.milageDrivenIbl.Size = new System.Drawing.Size(161, 34);
            this.milageDrivenIbl.TabIndex = 39;
            this.milageDrivenIbl.Text = "Enter total milage driven\r\n on vehicle:";
            // 
            // CarInventoryDataGridView
            // 
            this.CarInventoryDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CarInventoryDataGridView.Location = new System.Drawing.Point(490, 12);
            this.CarInventoryDataGridView.Name = "CarInventoryDataGridView";
            this.CarInventoryDataGridView.RowHeadersWidth = 51;
            this.CarInventoryDataGridView.RowTemplate.Height = 24;
            this.CarInventoryDataGridView.Size = new System.Drawing.Size(814, 314);
            this.CarInventoryDataGridView.TabIndex = 40;
            // 
            // RentCar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1349, 597);
            this.Controls.Add(this.CarInventoryDataGridView);
            this.Controls.Add(this.milageDrivenIbl);
            this.Controls.Add(this.milagedriventxt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.ReturnIbl);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.carnotavailableIbl);
            this.Controls.Add(this.RentOut);
            this.Controls.Add(this.DamagesOccuredtxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.ReturnCar);
            this.Controls.Add(this.rentingoutIbl);
            this.Controls.Add(this.DaysRentedtxt);
            this.Controls.Add(this.Addresstxt);
            this.Controls.Add(this.DateOfBirthtxt);
            this.Controls.Add(this.InsuranceCompanytxt);
            this.Controls.Add(this.DriversLicensetxt);
            this.Controls.Add(this.PhoneNumbertxt);
            this.Controls.Add(this.LastNametxt);
            this.Controls.Add(this.FirstNametxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.insuranceIbl);
            this.Controls.Add(this.DriversLicenseIbl);
            this.Controls.Add(this.customernameIbl);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.GoBacktoMain);
            this.Name = "RentCar";
            this.Text = "Renting a Car";
            this.Load += new System.EventHandler(this.RentCar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.CarInventoryDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button GoBacktoMain;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label customernameIbl;
        private System.Windows.Forms.Label DriversLicenseIbl;
        private System.Windows.Forms.Label insuranceIbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox FirstNametxt;
        private System.Windows.Forms.TextBox LastNametxt;
        private System.Windows.Forms.TextBox PhoneNumbertxt;
        private System.Windows.Forms.TextBox DriversLicensetxt;
        private System.Windows.Forms.TextBox InsuranceCompanytxt;
        private System.Windows.Forms.TextBox DateOfBirthtxt;
        private System.Windows.Forms.TextBox Addresstxt;
        private System.Windows.Forms.TextBox DaysRentedtxt;
        private System.Windows.Forms.Label rentingoutIbl;
        private System.Windows.Forms.Button ReturnCar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox DamagesOccuredtxt;
        private System.Windows.Forms.Button RentOut;
        private System.Windows.Forms.Label carnotavailableIbl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label ReturnIbl;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox milagedriventxt;
        private System.Windows.Forms.Label milageDrivenIbl;
        private System.Windows.Forms.DataGridView CarInventoryDataGridView;
    }
}