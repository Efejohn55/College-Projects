﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.OleDb;

namespace CarRentalService
{
    public partial class RentCar : Form
    {
        OleDbConnection myConnection;
        DataSet carDataSet;
        OleDbDataAdapter myDataAdapter;
        DataTable carTable;

        OleDbCommand carCommand;
        string carSQL;
        private List<Car> carList = new List<Car>();
        Car car = new Car();


        public RentCar()
        {
            InitializeComponent();
            this.FormClosed += RentCar_FormClosing;
        }

        private void GoBacktoMain_Click(object sender, EventArgs e)
        {
            this.Close();

            Mainfrm goback = new Mainfrm();
            goback.Show();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        private void RentCar_FormClosing(object sender, FormClosedEventArgs e)
        {
             carDatabase carDatabase = new carDatabase();

            carDatabase.AddAllToDatabase(CarInventoryDataGridView);


            
            
        }

        private void RentCar_Load(object sender, EventArgs e)
        {

            DataTable carTable = carDatabase.loadFromCarDatabase();
            BindingSource bs = new BindingSource();
            bs.DataSource = carTable;

            CarInventoryDataGridView.DataSource = bs;


        }

        private void SearchForRental_TextChanged(object sender, EventArgs e)
        {
           


        }

        private void RentOut_Click(object sender, EventArgs e)
        {

            if (FirstNametxt.Text == "") throw new Exception("please put in your first name");

            if (LastNametxt.Text == "") throw new Exception("please put in your last name");

            if (PhoneNumbertxt.Text == "") throw new Exception("please put in your phone number");

            if (DriversLicensetxt.Text == "") throw new Exception("please put in your drivers Id number");

            if (InsuranceCompanytxt.Text == "") throw new Exception("please put in the name of your insurance company");

            if (DateOfBirthtxt.Text == "") throw new Exception("please put in your Date Of Birth");

            if (Addresstxt.Text == "") throw new Exception("please put in your address of where you live");

            if (DaysRentedtxt.Text == "") throw new Exception("please enter the amount of days you plan to rent, or rented out(if returning) the vehicle");




           
            double addedtax = 0;
            double totalcostofrent = 0;

            DateTime time = DateTime.Now;

            CustomerInfo customer = new CustomerInfo(FirstNametxt.Text, LastNametxt.Text, PhoneNumbertxt.Text, DriversLicensetxt.Text, InsuranceCompanytxt.Text, DateOfBirthtxt.Text, Addresstxt.Text);









            DataGridViewRow selectedRow = CarInventoryDataGridView.SelectedRows[0];
            string carCateg = selectedRow.Cells[1].Value.ToString();
            string carMake = selectedRow.Cells[2].Value.ToString();
            string carModel = selectedRow.Cells[3].Value.ToString();
            int caryear = int.Parse(selectedRow.Cells[4].Value.ToString());
            double carMilage = double.Parse(selectedRow.Cells[5].Value.ToString());
            double carRentalCost = double.Parse(selectedRow.Cells[6].Value.ToString());
            string carAvailability = selectedRow.Cells[7].Value.ToString();
            string carDescription = selectedRow.Cells[8].Value.ToString();
            string carLocation = selectedRow.Cells[9].Value.ToString();
            string imageURL = selectedRow.Cells[10].Value.ToString();

            Car carsinfo = new Car(carCateg, carMake, carModel, caryear, carMilage, carRentalCost, carAvailability, carDescription, carLocation, imageURL);


            

            RentalCost rentcost = new RentalCost(int.Parse(DaysRentedtxt.Text), addedtax, carsinfo.CarRentalCost, totalcostofrent);

            if (carsinfo.CarAvailability == "Available")
            {
                carnotavailableIbl.Text = "";
                
               rentcost.TaxAmount = rentcost.RentalDays * carRentalCost * 0.06;
                rentcost.TotalCost = (rentcost.RentalDays * carRentalCost) + rentcost.TaxAmount;


                
                selectedRow.Cells[7].Value = "Rented";

                Recipt recipt = new Recipt(customer, rentcost, carsinfo);
                recipt.Show();
            }


            else if (carsinfo.CarAvailability == "Rented")
            {
                carnotavailableIbl.Text = "Chosen car not available for rent" +
                 ", please choose a different car";
            }




        }

        private void ReturnCar_Click(object sender, EventArgs e)
        {

            
            if (FirstNametxt.Text == "") throw new Exception("please put in your first name");

            if (LastNametxt.Text == "") throw new Exception("please put in your last name");

            if (PhoneNumbertxt.Text == "") throw new Exception("please put in your phone number");

            if (DriversLicensetxt.Text == "") throw new Exception("please put in your drivers Id number");

            if (InsuranceCompanytxt.Text == "") throw new Exception("please put in the name of your insurance company");

            if (DateOfBirthtxt.Text == "") throw new Exception("please put in your Date Of Birth");

            if (Addresstxt.Text == "") throw new Exception("please put in your address of where you live");

            CustomerInfo customer = new CustomerInfo(FirstNametxt.Text, LastNametxt.Text, PhoneNumbertxt.Text, DriversLicensetxt.Text, InsuranceCompanytxt.Text, DateOfBirthtxt.Text, Addresstxt.Text);

            DataGridViewRow selectedRow = CarInventoryDataGridView.SelectedRows[0];
            string carCateg = selectedRow.Cells[1].Value.ToString();
            string carMake = selectedRow.Cells[2].Value.ToString();
            string carModel = selectedRow.Cells[3].Value.ToString();
            int caryear = int.Parse(selectedRow.Cells[4].Value.ToString());
            double carMilage = double.Parse(selectedRow.Cells[5].Value.ToString());
            double carRentalCost = double.Parse(selectedRow.Cells[6].Value.ToString());
            string carAvailability = selectedRow.Cells[7].Value.ToString();
            string carDescription = selectedRow.Cells[8].Value.ToString();
            string carLocation = selectedRow.Cells[9].Value.ToString();
            string imageURL = selectedRow.Cells[10].Value.ToString();


            Car carsinfo = new Car(carCateg, carMake, carModel, caryear, carMilage, carRentalCost, carAvailability, carDescription, carLocation, imageURL);


            if (carsinfo.CarAvailability == "Rented")
            {

               
                selectedRow.Cells[7].Value = "Available";
            }

            else if (carsinfo.CarAvailability != "Rented") throw new Exception("You can not return a car that is not unavailable");

            if(!string.IsNullOrEmpty(DamagesOccuredtxt.Text))
            {
                selectedRow.Cells[8].Value = "damaged condition";
            }

            if (!string.IsNullOrEmpty(milagedriventxt.Text))
            {
                carsinfo.CarMilage += double.Parse(milagedriventxt.Text);

                selectedRow.Cells[5].Value = carsinfo.CarMilage.ToString();
               
            }

        }
    }

}
