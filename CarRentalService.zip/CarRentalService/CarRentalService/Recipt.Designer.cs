﻿
namespace CarRentalService
{
    partial class Recipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReciptIbl = new System.Windows.Forms.Label();
            this.firstnameIbl = new System.Windows.Forms.Label();
            this.lastnameIbl = new System.Windows.Forms.Label();
            this.phonenumberIbl = new System.Windows.Forms.Label();
            this.driversidIbl = new System.Windows.Forms.Label();
            this.insuranceIbl = new System.Windows.Forms.Label();
            this.daysrentedIbl = new System.Windows.Forms.Label();
            this.addedTaxIbl = new System.Windows.Forms.Label();
            this.totalcostIbl = new System.Windows.Forms.Label();
            this.DOBIbl = new System.Windows.Forms.Label();
            this.addressIbl = new System.Windows.Forms.Label();
            this.First = new System.Windows.Forms.Label();
            this.Last = new System.Windows.Forms.Label();
            this.phonenum = new System.Windows.Forms.Label();
            this.drivers = new System.Windows.Forms.Label();
            this.Insura = new System.Windows.Forms.Label();
            this.rented = new System.Windows.Forms.Label();
            this.tax = new System.Windows.Forms.Label();
            this.totalcost = new System.Windows.Forms.Label();
            this.dob = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.Label();
            this.dollarsign1Ibl = new System.Windows.Forms.Label();
            this.Dollarsign2Ibl = new System.Windows.Forms.Label();
            this.imageIbl = new System.Windows.Forms.Label();
            this.carPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.carPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // ReciptIbl
            // 
            this.ReciptIbl.AutoSize = true;
            this.ReciptIbl.Location = new System.Drawing.Point(8, 21);
            this.ReciptIbl.Name = "ReciptIbl";
            this.ReciptIbl.Size = new System.Drawing.Size(221, 17);
            this.ReciptIbl.TabIndex = 0;
            this.ReciptIbl.Text = "Here is your recipt for your rental:";
            // 
            // firstnameIbl
            // 
            this.firstnameIbl.AutoSize = true;
            this.firstnameIbl.Location = new System.Drawing.Point(113, 73);
            this.firstnameIbl.Name = "firstnameIbl";
            this.firstnameIbl.Size = new System.Drawing.Size(35, 17);
            this.firstnameIbl.TabIndex = 1;
            this.firstnameIbl.Text = "First";
            // 
            // lastnameIbl
            // 
            this.lastnameIbl.AutoSize = true;
            this.lastnameIbl.Location = new System.Drawing.Point(113, 104);
            this.lastnameIbl.Name = "lastnameIbl";
            this.lastnameIbl.Size = new System.Drawing.Size(74, 17);
            this.lastnameIbl.TabIndex = 2;
            this.lastnameIbl.Text = "Last name";
            // 
            // phonenumberIbl
            // 
            this.phonenumberIbl.AutoSize = true;
            this.phonenumberIbl.Location = new System.Drawing.Point(135, 147);
            this.phonenumberIbl.Name = "phonenumberIbl";
            this.phonenumberIbl.Size = new System.Drawing.Size(100, 17);
            this.phonenumberIbl.TabIndex = 3;
            this.phonenumberIbl.Text = "phone number";
            // 
            // driversidIbl
            // 
            this.driversidIbl.AutoSize = true;
            this.driversidIbl.Location = new System.Drawing.Point(156, 233);
            this.driversidIbl.Name = "driversidIbl";
            this.driversidIbl.Size = new System.Drawing.Size(120, 17);
            this.driversidIbl.TabIndex = 4;
            this.driversidIbl.Text = "drivers ID number";
            // 
            // insuranceIbl
            // 
            this.insuranceIbl.AutoSize = true;
            this.insuranceIbl.Location = new System.Drawing.Point(166, 192);
            this.insuranceIbl.Name = "insuranceIbl";
            this.insuranceIbl.Size = new System.Drawing.Size(97, 17);
            this.insuranceIbl.TabIndex = 5;
            this.insuranceIbl.Text = "insurance info";
            // 
            // daysrentedIbl
            // 
            this.daysrentedIbl.AutoSize = true;
            this.daysrentedIbl.Location = new System.Drawing.Point(169, 313);
            this.daysrentedIbl.Name = "daysrentedIbl";
            this.daysrentedIbl.Size = new System.Drawing.Size(107, 17);
            this.daysrentedIbl.TabIndex = 6;
            this.daysrentedIbl.Text = "days rented out";
            // 
            // addedTaxIbl
            // 
            this.addedTaxIbl.AutoSize = true;
            this.addedTaxIbl.Location = new System.Drawing.Point(135, 401);
            this.addedTaxIbl.Name = "addedTaxIbl";
            this.addedTaxIbl.Size = new System.Drawing.Size(85, 17);
            this.addedTaxIbl.TabIndex = 7;
            this.addedTaxIbl.Text = "added taxes";
            // 
            // totalcostIbl
            // 
            this.totalcostIbl.AutoSize = true;
            this.totalcostIbl.Location = new System.Drawing.Point(135, 450);
            this.totalcostIbl.Name = "totalcostIbl";
            this.totalcostIbl.Size = new System.Drawing.Size(65, 17);
            this.totalcostIbl.TabIndex = 8;
            this.totalcostIbl.Text = "total cost";
            // 
            // DOBIbl
            // 
            this.DOBIbl.AutoSize = true;
            this.DOBIbl.Location = new System.Drawing.Point(151, 277);
            this.DOBIbl.Name = "DOBIbl";
            this.DOBIbl.Size = new System.Drawing.Size(78, 17);
            this.DOBIbl.TabIndex = 9;
            this.DOBIbl.Text = "Dateofbirth";
            // 
            // addressIbl
            // 
            this.addressIbl.AutoSize = true;
            this.addressIbl.Location = new System.Drawing.Point(156, 350);
            this.addressIbl.Name = "addressIbl";
            this.addressIbl.Size = new System.Drawing.Size(108, 17);
            this.addressIbl.TabIndex = 10;
            this.addressIbl.Text = "addresslocation";
            // 
            // First
            // 
            this.First.AutoSize = true;
            this.First.Location = new System.Drawing.Point(15, 73);
            this.First.Name = "First";
            this.First.Size = new System.Drawing.Size(80, 17);
            this.First.TabIndex = 11;
            this.First.Text = "First Name:";
            // 
            // Last
            // 
            this.Last.AutoSize = true;
            this.Last.Location = new System.Drawing.Point(15, 104);
            this.Last.Name = "Last";
            this.Last.Size = new System.Drawing.Size(80, 17);
            this.Last.TabIndex = 12;
            this.Last.Text = "Last Name:";
            // 
            // phonenum
            // 
            this.phonenum.AutoSize = true;
            this.phonenum.Location = new System.Drawing.Point(10, 147);
            this.phonenum.Name = "phonenum";
            this.phonenum.Size = new System.Drawing.Size(107, 17);
            this.phonenum.TabIndex = 13;
            this.phonenum.Text = "Phone Number:";
            // 
            // drivers
            // 
            this.drivers.AutoSize = true;
            this.drivers.Location = new System.Drawing.Point(15, 233);
            this.drivers.Name = "drivers";
            this.drivers.Size = new System.Drawing.Size(122, 17);
            this.drivers.TabIndex = 14;
            this.drivers.Text = "drivers Id number:";
            // 
            // Insura
            // 
            this.Insura.AutoSize = true;
            this.Insura.Location = new System.Drawing.Point(11, 192);
            this.Insura.Name = "Insura";
            this.Insura.Size = new System.Drawing.Size(137, 17);
            this.Insura.TabIndex = 15;
            this.Insura.Text = "Insurance Company:";
            // 
            // rented
            // 
            this.rented.AutoSize = true;
            this.rented.Location = new System.Drawing.Point(10, 313);
            this.rented.Name = "rented";
            this.rented.Size = new System.Drawing.Size(142, 17);
            this.rented.TabIndex = 16;
            this.rented.Text = "Days vehicle Rented:";
            // 
            // tax
            // 
            this.tax.AutoSize = true;
            this.tax.Location = new System.Drawing.Point(12, 401);
            this.tax.Name = "tax";
            this.tax.Size = new System.Drawing.Size(80, 17);
            this.tax.TabIndex = 17;
            this.tax.Text = "Taxes cost:";
            // 
            // totalcost
            // 
            this.totalcost.AutoSize = true;
            this.totalcost.Location = new System.Drawing.Point(11, 450);
            this.totalcost.Name = "totalcost";
            this.totalcost.Size = new System.Drawing.Size(76, 17);
            this.totalcost.TabIndex = 18;
            this.totalcost.Text = "Total Cost:";
            // 
            // dob
            // 
            this.dob.AutoSize = true;
            this.dob.Location = new System.Drawing.Point(15, 277);
            this.dob.Name = "dob";
            this.dob.Size = new System.Drawing.Size(94, 17);
            this.dob.TabIndex = 19;
            this.dob.Text = "Date Of Birth:";
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Location = new System.Drawing.Point(8, 350);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(129, 17);
            this.address.TabIndex = 20;
            this.address.Text = "Addresss Location:";
            // 
            // dollarsign1Ibl
            // 
            this.dollarsign1Ibl.AutoSize = true;
            this.dollarsign1Ibl.Location = new System.Drawing.Point(93, 401);
            this.dollarsign1Ibl.Name = "dollarsign1Ibl";
            this.dollarsign1Ibl.Size = new System.Drawing.Size(16, 17);
            this.dollarsign1Ibl.TabIndex = 21;
            this.dollarsign1Ibl.Text = "$\r\n";
            // 
            // Dollarsign2Ibl
            // 
            this.Dollarsign2Ibl.AutoSize = true;
            this.Dollarsign2Ibl.Location = new System.Drawing.Point(93, 450);
            this.Dollarsign2Ibl.Name = "Dollarsign2Ibl";
            this.Dollarsign2Ibl.Size = new System.Drawing.Size(16, 17);
            this.Dollarsign2Ibl.TabIndex = 22;
            this.Dollarsign2Ibl.Text = "$\r\n";
            // 
            // imageIbl
            // 
            this.imageIbl.AutoSize = true;
            this.imageIbl.Location = new System.Drawing.Point(600, 118);
            this.imageIbl.Name = "imageIbl";
            this.imageIbl.Size = new System.Drawing.Size(147, 17);
            this.imageIbl.TabIndex = 23;
            this.imageIbl.Text = "Image Of Car Chosen:";
            // 
            // carPictureBox
            // 
            this.carPictureBox.Location = new System.Drawing.Point(589, 147);
            this.carPictureBox.Name = "carPictureBox";
            this.carPictureBox.Size = new System.Drawing.Size(290, 250);
            this.carPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.carPictureBox.TabIndex = 24;
            this.carPictureBox.TabStop = false;
            // 
            // Recipt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 549);
            this.Controls.Add(this.carPictureBox);
            this.Controls.Add(this.imageIbl);
            this.Controls.Add(this.Dollarsign2Ibl);
            this.Controls.Add(this.dollarsign1Ibl);
            this.Controls.Add(this.address);
            this.Controls.Add(this.dob);
            this.Controls.Add(this.totalcost);
            this.Controls.Add(this.tax);
            this.Controls.Add(this.rented);
            this.Controls.Add(this.Insura);
            this.Controls.Add(this.drivers);
            this.Controls.Add(this.phonenum);
            this.Controls.Add(this.Last);
            this.Controls.Add(this.First);
            this.Controls.Add(this.addressIbl);
            this.Controls.Add(this.DOBIbl);
            this.Controls.Add(this.totalcostIbl);
            this.Controls.Add(this.addedTaxIbl);
            this.Controls.Add(this.daysrentedIbl);
            this.Controls.Add(this.insuranceIbl);
            this.Controls.Add(this.driversidIbl);
            this.Controls.Add(this.phonenumberIbl);
            this.Controls.Add(this.lastnameIbl);
            this.Controls.Add(this.firstnameIbl);
            this.Controls.Add(this.ReciptIbl);
            this.Name = "Recipt";
            this.Text = "Recipt";
            this.Load += new System.EventHandler(this.Recipt_Load);
            ((System.ComponentModel.ISupportInitialize)(this.carPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ReciptIbl;
        private System.Windows.Forms.Label firstnameIbl;
        private System.Windows.Forms.Label lastnameIbl;
        private System.Windows.Forms.Label phonenumberIbl;
        private System.Windows.Forms.Label driversidIbl;
        private System.Windows.Forms.Label insuranceIbl;
        private System.Windows.Forms.Label daysrentedIbl;
        private System.Windows.Forms.Label addedTaxIbl;
        private System.Windows.Forms.Label totalcostIbl;
        private System.Windows.Forms.Label DOBIbl;
        private System.Windows.Forms.Label addressIbl;
        private System.Windows.Forms.Label First;
        private System.Windows.Forms.Label Last;
        private System.Windows.Forms.Label phonenum;
        private System.Windows.Forms.Label drivers;
        private System.Windows.Forms.Label Insura;
        private System.Windows.Forms.Label rented;
        private System.Windows.Forms.Label tax;
        private System.Windows.Forms.Label totalcost;
        private System.Windows.Forms.Label dob;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label dollarsign1Ibl;
        private System.Windows.Forms.Label Dollarsign2Ibl;
        private System.Windows.Forms.Label imageIbl;
        private System.Windows.Forms.PictureBox carPictureBox;
    }
}