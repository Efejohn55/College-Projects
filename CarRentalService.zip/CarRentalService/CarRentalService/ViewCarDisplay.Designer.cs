﻿
namespace CarRentalService
{
    partial class ViewCarDisplay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.carMakeIbl = new System.Windows.Forms.Label();
            this.carModelIbl = new System.Windows.Forms.Label();
            this.yearIbl = new System.Windows.Forms.Label();
            this.carMilageIbl = new System.Windows.Forms.Label();
            this.carRentalCostIbl = new System.Windows.Forms.Label();
            this.carAvailabaleIbl = new System.Windows.Forms.Label();
            this.descriptionIbl = new System.Windows.Forms.Label();
            this.carLocationIbl = new System.Windows.Forms.Label();
            this.carPictureBox = new System.Windows.Forms.PictureBox();
            this.makeIbl = new System.Windows.Forms.Label();
            this.modelIbl = new System.Windows.Forms.Label();
            this.yearcarIbl = new System.Windows.Forms.Label();
            this.milageIbl = new System.Windows.Forms.Label();
            this.rentalIbl = new System.Windows.Forms.Label();
            this.availableIbl = new System.Windows.Forms.Label();
            this.descripIbl = new System.Windows.Forms.Label();
            this.locationIbl = new System.Windows.Forms.Label();
            this.carCategoreyIbl = new System.Windows.Forms.Label();
            this.categoryIbl = new System.Windows.Forms.Label();
            this.carimgIbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.carPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // carMakeIbl
            // 
            this.carMakeIbl.AutoSize = true;
            this.carMakeIbl.Location = new System.Drawing.Point(82, 60);
            this.carMakeIbl.Name = "carMakeIbl";
            this.carMakeIbl.Size = new System.Drawing.Size(72, 17);
            this.carMakeIbl.TabIndex = 0;
            this.carMakeIbl.Text = "Car Make:";
            // 
            // carModelIbl
            // 
            this.carModelIbl.AutoSize = true;
            this.carModelIbl.Location = new System.Drawing.Point(85, 90);
            this.carModelIbl.Name = "carModelIbl";
            this.carModelIbl.Size = new System.Drawing.Size(76, 17);
            this.carModelIbl.TabIndex = 1;
            this.carModelIbl.Text = "Car Model:";
            // 
            // yearIbl
            // 
            this.yearIbl.AutoSize = true;
            this.yearIbl.Location = new System.Drawing.Point(88, 125);
            this.yearIbl.Name = "yearIbl";
            this.yearIbl.Size = new System.Drawing.Size(42, 17);
            this.yearIbl.TabIndex = 2;
            this.yearIbl.Text = "Year:";
            // 
            // carMilageIbl
            // 
            this.carMilageIbl.AutoSize = true;
            this.carMilageIbl.Location = new System.Drawing.Point(88, 168);
            this.carMilageIbl.Name = "carMilageIbl";
            this.carMilageIbl.Size = new System.Drawing.Size(79, 17);
            this.carMilageIbl.TabIndex = 3;
            this.carMilageIbl.Text = "Car Milage:";
            // 
            // carRentalCostIbl
            // 
            this.carRentalCostIbl.AutoSize = true;
            this.carRentalCostIbl.Location = new System.Drawing.Point(82, 204);
            this.carRentalCostIbl.Name = "carRentalCostIbl";
            this.carRentalCostIbl.Size = new System.Drawing.Size(111, 17);
            this.carRentalCostIbl.TabIndex = 4;
            this.carRentalCostIbl.Text = "Car Rental Cost:";
            // 
            // carAvailabaleIbl
            // 
            this.carAvailabaleIbl.AutoSize = true;
            this.carAvailabaleIbl.Location = new System.Drawing.Point(82, 239);
            this.carAvailabaleIbl.Name = "carAvailabaleIbl";
            this.carAvailabaleIbl.Size = new System.Drawing.Size(104, 17);
            this.carAvailabaleIbl.TabIndex = 5;
            this.carAvailabaleIbl.Text = "Car Availability:";
            // 
            // descriptionIbl
            // 
            this.descriptionIbl.AutoSize = true;
            this.descriptionIbl.Location = new System.Drawing.Point(82, 279);
            this.descriptionIbl.Name = "descriptionIbl";
            this.descriptionIbl.Size = new System.Drawing.Size(121, 17);
            this.descriptionIbl.TabIndex = 6;
            this.descriptionIbl.Text = "description of car:";
            // 
            // carLocationIbl
            // 
            this.carLocationIbl.AutoSize = true;
            this.carLocationIbl.Location = new System.Drawing.Point(82, 312);
            this.carLocationIbl.Name = "carLocationIbl";
            this.carLocationIbl.Size = new System.Drawing.Size(90, 17);
            this.carLocationIbl.TabIndex = 7;
            this.carLocationIbl.Text = "car Location:";
            // 
            // carPictureBox
            // 
            this.carPictureBox.Location = new System.Drawing.Point(516, 79);
            this.carPictureBox.Name = "carPictureBox";
            this.carPictureBox.Size = new System.Drawing.Size(295, 260);
            this.carPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.carPictureBox.TabIndex = 8;
            this.carPictureBox.TabStop = false;
            // 
            // makeIbl
            // 
            this.makeIbl.AutoSize = true;
            this.makeIbl.Location = new System.Drawing.Point(156, 60);
            this.makeIbl.Name = "makeIbl";
            this.makeIbl.Size = new System.Drawing.Size(42, 17);
            this.makeIbl.TabIndex = 9;
            this.makeIbl.Text = "make";
            // 
            // modelIbl
            // 
            this.modelIbl.AutoSize = true;
            this.modelIbl.Location = new System.Drawing.Point(164, 90);
            this.modelIbl.Name = "modelIbl";
            this.modelIbl.Size = new System.Drawing.Size(46, 17);
            this.modelIbl.TabIndex = 10;
            this.modelIbl.Text = "model";
            // 
            // yearcarIbl
            // 
            this.yearcarIbl.AutoSize = true;
            this.yearcarIbl.Location = new System.Drawing.Point(159, 125);
            this.yearcarIbl.Name = "yearcarIbl";
            this.yearcarIbl.Size = new System.Drawing.Size(36, 17);
            this.yearcarIbl.TabIndex = 11;
            this.yearcarIbl.Text = "year";
            // 
            // milageIbl
            // 
            this.milageIbl.AutoSize = true;
            this.milageIbl.Location = new System.Drawing.Point(174, 168);
            this.milageIbl.Name = "milageIbl";
            this.milageIbl.Size = new System.Drawing.Size(49, 17);
            this.milageIbl.TabIndex = 12;
            this.milageIbl.Text = "milage";
            // 
            // rentalIbl
            // 
            this.rentalIbl.AutoSize = true;
            this.rentalIbl.Location = new System.Drawing.Point(200, 204);
            this.rentalIbl.Name = "rentalIbl";
            this.rentalIbl.Size = new System.Drawing.Size(44, 17);
            this.rentalIbl.TabIndex = 13;
            this.rentalIbl.Text = "rental";
            // 
            // availableIbl
            // 
            this.availableIbl.AutoSize = true;
            this.availableIbl.Location = new System.Drawing.Point(193, 239);
            this.availableIbl.Name = "availableIbl";
            this.availableIbl.Size = new System.Drawing.Size(64, 17);
            this.availableIbl.TabIndex = 14;
            this.availableIbl.Text = "available";
            // 
            // descripIbl
            // 
            this.descripIbl.AutoSize = true;
            this.descripIbl.Location = new System.Drawing.Point(210, 279);
            this.descripIbl.Name = "descripIbl";
            this.descripIbl.Size = new System.Drawing.Size(77, 17);
            this.descripIbl.TabIndex = 15;
            this.descripIbl.Text = "description";
            // 
            // locationIbl
            // 
            this.locationIbl.AutoSize = true;
            this.locationIbl.Location = new System.Drawing.Point(196, 312);
            this.locationIbl.Name = "locationIbl";
            this.locationIbl.Size = new System.Drawing.Size(57, 17);
            this.locationIbl.TabIndex = 16;
            this.locationIbl.Text = "location";
            // 
            // carCategoreyIbl
            // 
            this.carCategoreyIbl.AutoSize = true;
            this.carCategoreyIbl.Location = new System.Drawing.Point(88, 24);
            this.carCategoreyIbl.Name = "carCategoreyIbl";
            this.carCategoreyIbl.Size = new System.Drawing.Size(91, 17);
            this.carCategoreyIbl.TabIndex = 17;
            this.carCategoreyIbl.Text = "CarCategory:";
            // 
            // categoryIbl
            // 
            this.categoryIbl.AutoSize = true;
            this.categoryIbl.Location = new System.Drawing.Point(185, 24);
            this.categoryIbl.Name = "categoryIbl";
            this.categoryIbl.Size = new System.Drawing.Size(63, 17);
            this.categoryIbl.TabIndex = 18;
            this.categoryIbl.Text = "category";
            // 
            // carimgIbl
            // 
            this.carimgIbl.AutoSize = true;
            this.carimgIbl.Location = new System.Drawing.Point(529, 49);
            this.carimgIbl.Name = "carimgIbl";
            this.carimgIbl.Size = new System.Drawing.Size(76, 17);
            this.carimgIbl.TabIndex = 19;
            this.carimgIbl.Text = "Car Image:";
            // 
            // ViewCarDisplay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(850, 457);
            this.Controls.Add(this.carimgIbl);
            this.Controls.Add(this.categoryIbl);
            this.Controls.Add(this.carCategoreyIbl);
            this.Controls.Add(this.locationIbl);
            this.Controls.Add(this.descripIbl);
            this.Controls.Add(this.availableIbl);
            this.Controls.Add(this.rentalIbl);
            this.Controls.Add(this.milageIbl);
            this.Controls.Add(this.yearcarIbl);
            this.Controls.Add(this.modelIbl);
            this.Controls.Add(this.makeIbl);
            this.Controls.Add(this.carPictureBox);
            this.Controls.Add(this.carLocationIbl);
            this.Controls.Add(this.descriptionIbl);
            this.Controls.Add(this.carAvailabaleIbl);
            this.Controls.Add(this.carRentalCostIbl);
            this.Controls.Add(this.carMilageIbl);
            this.Controls.Add(this.yearIbl);
            this.Controls.Add(this.carModelIbl);
            this.Controls.Add(this.carMakeIbl);
            this.Name = "ViewCarDisplay";
            this.Text = "ViewCarDisplay";
            this.Load += new System.EventHandler(this.ViewCarDisplay_Load);
            ((System.ComponentModel.ISupportInitialize)(this.carPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label carMakeIbl;
        private System.Windows.Forms.Label carModelIbl;
        private System.Windows.Forms.Label yearIbl;
        private System.Windows.Forms.Label carMilageIbl;
        private System.Windows.Forms.Label carRentalCostIbl;
        private System.Windows.Forms.Label carAvailabaleIbl;
        private System.Windows.Forms.Label descriptionIbl;
        private System.Windows.Forms.Label carLocationIbl;
        private System.Windows.Forms.PictureBox carPictureBox;
        private System.Windows.Forms.Label makeIbl;
        private System.Windows.Forms.Label modelIbl;
        private System.Windows.Forms.Label yearcarIbl;
        private System.Windows.Forms.Label milageIbl;
        private System.Windows.Forms.Label rentalIbl;
        private System.Windows.Forms.Label availableIbl;
        private System.Windows.Forms.Label descripIbl;
        private System.Windows.Forms.Label locationIbl;
        private System.Windows.Forms.Label carCategoreyIbl;
        private System.Windows.Forms.Label categoryIbl;
        private System.Windows.Forms.Label carimgIbl;
    }
}