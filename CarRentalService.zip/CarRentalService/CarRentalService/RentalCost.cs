﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarRentalService
{
    public class RentalCost
    {

        private int rentaldays;
        private double taxAmount = 0.06;
        private double carRentalCost;
        private double totalCost;


        

        public RentalCost()
        {

        }
        
        public RentalCost(int rentDays, double taxAmountForRent, double rentalCost, double totalCostForCar)
        {
            this.rentaldays = rentDays;
            this.taxAmount = taxAmountForRent;
            this.totalCost = totalCostForCar;
            this.carRentalCost = rentalCost;
        }


        public int RentalDays
        {
            get { return rentaldays;}

            set { rentaldays = value; }

        }

        public double TaxAmount
        {
            get { return taxAmount;  }

            set { taxAmount = value; }
        }

        public double Rental
        {
            get { return carRentalCost; }
            set { carRentalCost = value; }
        }

        public double TotalCost
        {
            get { return totalCost; }

            set { totalCost = value; }
        }

        

        public double calculateTax(int rentDays, double rentCost)
        {
            taxAmount = rentDays * rentCost * 0.06;


            return taxAmount;

        }

        public double calculateTotal(int rentDays, double taxAmount, double rentCost)
        {
            totalCost = (rentDays * rentCost) + taxAmount;

            return totalCost;
        }




    }
}
