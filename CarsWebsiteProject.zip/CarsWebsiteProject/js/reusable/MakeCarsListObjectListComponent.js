"use strict";
function MakeCarsListObjectListComponent({ carsObjArray = " default obj array" }) {

    function MakeCarsObjectComponent({ carsObj = "default obj" }) {

        // This is the DOM element that will be returned.
        var carsObj = document.createElement("div");

        carsObj.classList.add("carObjectComponent"); // style object with the ".car" rules from file car.css
       
        // price is private property of carObj (because normal variable declaration in MakeCar
        var type = carsObj.theType || "select type of car";

        var salary = carsObj.theSalary || "$$$";
        var imgURL = carsObj.imgURL || "pics/audirs5.jpg";
        var likes = 0;
        var dislikes = 0;

        // Condition setter method (public) - could be used from outside MakeCar
        carsObj.setName = function (newName) {
            carsObj.name = newName;
            display(); // show updated property on the page
        };

        carsObj.setType = function (newType) {
            type = newType;
            display();
        };


        // public method to modify price 
        carsObj.changeSalary = function (changeRate) {
            var n = Number(changeRate);
            console.log("changing price by this rate " + n);
            salary = (0.15 * n);
            display(); // show updated price on the page
        };

        // Build the UI.
        carsObj.innerHTML = `
      <div class='carsInfoClass'></div>
      <button class='nameButtonClass'>Set to car brand/model that you would like to have: </button>
      <input class='newNameInputClass'/> <br/>
<button class='typeButtonClass'>Input Type of car interested in, like sport or luxury for example: </button>
      <input class='newTypeInputClass'/> <br/>
      <button class='salaryButtonClass'>Enter in your monthly net income to see how much of a monthly car payment you can comfortably afford based on 15 percent of your take home pay: </button>
      <input class='salaryInputClass'/> 

    `;

        // Create variable references for all DOM elements (above) that we need to programatically access. 
        var carsInfo = carsObj.getElementsByClassName("carsInfoClass")[0];
        var nameButton = carsObj.getElementsByClassName("nameButtonClass")[0];
        var newNameInput = carsObj.getElementsByClassName("newNameInputClass")[0];
        var typeButton = carsObj.getElementsByClassName("typeButtonClass")[0];
        var newTypeInput = carsObj.getElementsByClassName("newTypeInputClass")[0];
        var salaryButton = carsObj.getElementsByClassName("salaryButtonClass")[0];
        var salaryInput = carsObj.getElementsByClassName("salaryInputClass")[0];


        var likeImg = document.createElement("img");
        var dislikeImage = document.createElement("img");
        likeImg.src = "pics/like.png";
        likeImg.classList.add("likeImg");
        dislikeImage.src = "pics/dislike.png";
        dislikeImage.classList.add("dislikeImage");
        carsObj.appendChild(likeImg);
        carsObj.appendChild(dislikeImage);

        likeImg.onclick = function () {
            likes++;
            display();
        };

        dislikeImage.onclick = function () {
            dislikes++;
            display();
        };

        var likeSpan = document.createElement("span"); // span is a container like a div, 
        var dislikeSpan = document.createElement("span"); // but does not start and end on a new line.
        carsObj.appendChild(likeSpan);
        carsObj.appendChild(dislikeSpan);





        nameButton.onclick = function () {
            carsObj.setName(newNameInput.value);
        };

        typeButton.onclick = function () {
            carsObj.setType(newTypeInput.value);
        };
        salaryButton.onclick = function () {
            carsObj.changeSalary(salaryInput.value);
        };


        function formatCurrency(salary) {
            return salary.toLocaleString("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 3 });
        }






        // private method display, refreshes the Info div with current values for 
        // condition and price. 
        var display = function () {
            carsInfo.innerHTML = `

<img src='${imgURL}'/>
          <p>
         Name:  ${carsObj.name} <br/>
             Type: ${type}<br/>
             Affordable monthly car payment based on monthly net income entered: ${formatCurrency(salary)}
           
          </p>
        `
            likeSpan.innerHTML = likes + " likes    ";
            dislikeSpan.innerHTML = dislikes + " dislikes    ";
            ;
        };
        display(); // do this or the carInfo area will be blank initially


        return carsObj;

    }

    var containerDiv = document.createElement("div");
    containerDiv.classList.add("carListObjectComponent");


    for (var theCarObj of carsObjArray) {
        containerDiv.appendChild(MakeCarsObjectComponent(theCarObj));
    }
    return containerDiv;
  
}