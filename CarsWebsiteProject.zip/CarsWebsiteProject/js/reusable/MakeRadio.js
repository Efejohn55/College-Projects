"use strict";
function MakeRadio( {prompt, choices, selected, parent } ) {

    var form = MakeTag({
        htmlTag: "form",
        cssClass: "radio"
    });

    prompt = prompt || "unknown prompt";

    if (!choices || !choices[0]) {
        alert("MakeRadio needs a parameter object with a 'choices' property (an array of choices)");
        return form;
    }

    selected = selected || ""; 

    for (var choice of choices) {
        var para = MakeTag({
            htmlTag: "p",
            parent: form
        });

        var option = MakeTag({
            htmlTag: "input",
            type: "radio",
            name: "radName",
            value: choice,
            parent: para
        });

        MakeTag({
            htmlTag: "span",
            innerHTML: choice,
            parent: para
        });

        if (selected == choice) {
            option.checked = true;
            form.value = choice;
        }

        option.onclick = function () {
            form.value = form.radName.value;
        };
    }

    if(parent) {
        parent.appendChild(form);
    }

    return form;
}