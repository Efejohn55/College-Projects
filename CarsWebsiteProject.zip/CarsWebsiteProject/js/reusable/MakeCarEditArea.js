"use strict";
function MakeCarEditArea({ inputSpecs, successCallBack, cancelCallBack, title = "Untitled"}) {

    var header = document.createElement("h1");
    header.textContent = title;

    // defensive (provider style) programming. First check if params has everything we need...
    if (!inputSpecs || !inputSpecs[0]) {
        var errorMsg = "MakeEditArea did not receive a parameter property named 'inputSpecs'\n" +
            "that has at least one object (defining an input field).";
        alert(errorMsg); // this would generally be a programmer error, not user error
        throw errorMsg;
        return;
    }

    if (!successCallBack || !(successCallBack instanceof Function)) {
        var errorMsg = "MakeEditArea did not receive a parameter property named 'successCallBack',\n" +
            "a Consumer function that will be called (passing an object full of user entered data)\n" +
            "if the user clicks 'Submit' and everything validates.";
        alert(errorMsg); // this would generally be a programmer error, not user error
        throw errorMsg;
        return;
    }

    if (!cancelCallBack || !(cancelCallBack instanceof Function)) {
        var errorMsg = "MakeEditArea did not receive a parameter property named 'cancelCallBack',\n" +
            "a Consumer function that will be called if the user clicks 'Cancel'.\n" +
            "(no input will be passed to the cancel call back function).";
        alert(errorMsg); // this would generally be a programmer error, not user error
        throw errorMsg;
        return;
    }

    // ENTRY POINT (after defensive programming/error checking)
    var editDiv = MakeTag({
        htmlTag: "div",
        cssClass: "editArea"
    });
    // MakeTag required property: params.htmlTag
    // opt'l properties: innerHTML, cssClass, src, parent

    var header = MakeTag({
        htmlTag: "h1",
        innerHTML: title || "Untitled",
        parent: editDiv
    });

    for (var spec of inputSpecs) {

        // Add prompt to the DOM
        MakeTag({
            htmlTag: "span",
            innerHTML: spec.prompt,
            parent: editDiv
        });

        // Add input element to the DOM based on inputType
        if (spec.inputType == "text") {
            spec.inputTag = MakeTag({
                htmlTag: "input",
                parent: editDiv
            });
        } else if (spec.inputType == "radio") {
            console.log("Radio");
            spec.inputTag = MakeRadio({
                choices: spec.choices,
                selected: spec.selected,
                parent: editDiv
            });
        } else if (spec.inputType == "select") {
            spec.inputTag = MakeTag({
                htmlTag: "select",
                parent: editDiv
            });
            for (var choice of spec.choices) {
                var option = MakeTag({
                    htmlTag: "option",
                    innerHTML: choice,
                    parent: spec.inputTag
                });
            }
        }

        // Add error message to the DOM
        spec.errorMsg = MakeTag({
            htmlTag: "span",
            innerHTML: "&nbsp;",
            parent: editDiv
        });

        // Add line break to the DOM
        MakeTag({
            htmlTag: "br",
            parent: editDiv
        });
    }

    // Add a new line before the submit and cancel buttons
    MakeTag({// dont need a reference to this tag (so not saving MakeTag's return value).
        htmlTag: "br",
        parent: editDiv
    });

    var submitButton = MakeTag({
        htmlTag: "button",
        innerHTML: "Submit",
        parent: editDiv
    });

    submitButton.onclick = function () {

        var allGood = true;
        for (var spec of inputSpecs) {
            //min char len
            if (spec.inputTag.value.length < spec.minLen) {
                spec.errorMsg.innerHTML = " Error: input must have at least " + spec.minLen + " character(s).";
                allGood = false;
            } else {
                spec.errorMsg.innerHTML = "&nbsp;"; // wipe any previous error message that might be there.
            }
            //max char len
            if (spec.inputTag.value.length > spec.maxLen) {
                spec.errorMsg.innerHTML = " Error: input must have at most " + spec.maxLen + " character(s).";
                allGood = false;
            } else {
                spec.errorMsg.innerHTML = "&nbsp;"; // wipe any previous error message that might be there.
            }
        
        if (!allGood) {
            editDiv.recordLevelMsg.innerHTML = "Please Try Again";
            return;
            }

        // Check for date input
        if (spec.dataType === "date") {
            if (!/^\d{4}-\d{2}-\d{2}$/.test(spec.inputTag.value)) {
                spec.errorMsg.innerHTML = " Error: invalid date format (yyyy-mm-dd).";
                allGood = false;
                if (!allGood) {
                    editDiv.recordLevelMsg.innerHTML = "Please Try Again, Enter a valid date(year-month-day)";
                    return;
                }
            } else {
                spec.errorMsg.innerHTML = "&nbsp;"; // wipe any previous error message that might be there.
            }
        }
        // Check for number input
            if (spec.dataType === "number") {
                if (isNaN(spec.inputTag.value)) {
                    spec.errorMsg.innerHTML = " Error: invalid number format.";

                    allGood = false;
                    if (!allGood) {
                        editDiv.recordLevelMsg.innerHTML = "Please Try Again, Enter a valid Number";
                        return;
                    }
                } else {
                    spec.errorMsg.innerHTML = "&nbsp;"; // wipe any previous error message that might be there.
                }
            }
        }

        // Build object full of user data to pass to the success call back function
        editDiv.recordLevelMsg.innerHTML = "Data Accepted !";
        var inputVals = {};
        for (var spec of inputSpecs) {
            inputVals[spec.fieldName] = spec.inputTag.value;
        }
        successCallBack(inputVals);
    };

    var cancelButton = MakeTag({
        htmlTag: "button",
        innerHTML: "Cancel",
        parent: editDiv
    });

    cancelButton.onclick = function () {
        cancelCallBack();
    };

    function clearAll() {
        // Blank out all input tags and also the record level message.
        for (var spec of inputSpecs) {
            spec.inputTag.value = "";
        }
        editDiv.recordLevelMsg.innerHTML = "";
    }

    cancelButton.onclick = function () {
        // Since the user is cancelling, clear out all inputs and record level msg. 
        clearAll();

        // inform the consumer that the user cancelled (let them do what they want about that). 
        cancelCallBack();
    };

    editDiv.recordLevelMsg = MakeTag({
        htmlTag: "span",
        cssClass: "recLevelMsg",
        parent: editDiv
    });

    return editDiv;
}