"use strict";
function MakeCarClickSortTable({ title, objList, initialSortCol, sortIcon, numProps1stMobileCol } ) {

    var forwardSort = 1; // initial sort is forward

    // This function sorts the array of objects in "list" by object property "byProperty". 
    function jsSort(objList, byProperty) {

        var obj = objList[0];
        if (!obj[byProperty]) {
            var message = "objList does not have property " + byProperty + " -- cannot sort by that property.";
            throw message;
            return;  // early return -- dont try to sort.
        }

        if (obj[byProperty].sortOrder === null) {
            var message = "Cannot sort objList by property " + byProperty +
                    " because this property never had it's sortOrder set (by a method in SortableTableUtils.js).";
            throw message;
            return;  // early return -- dont try to sort.
        }

        /* q and z are just elements in the array and the function you write below has to return 
         negative or positive or zero */

        objList.sort(function (q, z) {  // in line (and anonymous) def'n of fn to compare list elements. 

            // q and z are objects to be compared. Their 'byProperty' property is the <td> by which we want to sort
            var qVal = q[byProperty].sortOrder;
            var zVal = z[byProperty].sortOrder;

            var c = 0;
            if (qVal > zVal) {
                c = 1;
            } else if (qVal < zVal) {
                c = -1;
            }
            c *= forwardSort; // c * 1 if forward, c * -1 if reverse
            return c;
        });

    } // jsSort

    // Create and return an HTML <tr> tag for the given obj (which comes from the object list). 
    function makeTableRow(obj, numProps1stMobileCol) {

        var tableRow = document.createElement("tr");

        tableRow.innerHTML = `
          <td class="mobCell identColC">
          </td>
          <td class="mobCell infoColC">
          </td>
        `;

        var identCol = tableRow.getElementsByClassName("identColC")[0];
        var infoCol = tableRow.getElementsByClassName("infoColC")[0];
        // The rest of the <td>s will show horizontally, only in desktop.


        var i = 0;
        for (var prop in obj) {

            // The innerHTML of each <td> (property of obj) gets added to one of 
            // the first two mobile columns (added vertically with new lines between)
            if (i < 1) {
                identCol.innerHTML += obj[prop].innerHTML;
            } else if (i < numProps1stMobileCol) {
                identCol.innerHTML += "<br/>" + obj[prop].innerHTML;
            } else if (i === numProps1stMobileCol) {
                infoCol.innerHTML += obj[prop].innerHTML;
            } else {
                infoCol.innerHTML += "<br/>" + obj[prop].innerHTML;
            }
            i++;
            // These same <td>s (of obj) will be added to desktop columns 
            // and will show horizontally. 
            tableRow.appendChild(obj[prop]);
            // style this cell to show only in desktop.
            obj[prop].classList.add("deskCell");
        }
        return tableRow;
    } // makeTableRow

    // Return true if any property of obj contains searchKey. Otherwise, return false.
    function isToShow(obj, searchKey) {

        // show the object if searchKey is empty
        if (!searchKey || searchKey.length === 0) {
            return true;
        }

        // convert search key to upper case (will convert values also to upper case before comparing).
        var searchKeyUpper = searchKey.toUpperCase();

        for (var prop in obj) {

            // Do not try to find a match for Table cells that hold images. 
            if (prop[0] !== "_") {

                // pull out the innerHTML because all properties of obj are actually <td> tags, not just text.
                var propVal = obj[prop].innerHTML; // associative array, using property name as if index. 
                var propValUpper = propVal.toUpperCase(); // convert to upper case to match searchKey.

                console.log("checking if " + searchKeyUpper + " is in " + propValUpper);

                if (propValUpper.includes(searchKeyUpper)) {
                    console.log("Yes it is inside");
                    return true;
                }
            } // excluding image tds
        }
        console.log("no it is not inside");
        return false;
    } // isToShow 

    // Remove the tbody from 'table' (if there is one). Sort 'list' by 'sortOrderPropName'. 
    // Then add a new tbody to table, inserting rows from the sorted list.
    function addTableBody(table, list, sortOrderPropName, filterValue) {

        // remove old tbody element if there is one (else you'll get the new sorted rows 
        // added to end of what's there).
        var oldBody = table.getElementsByTagName("tbody");
        if (oldBody[0]) {
            console.log("ready to remove oldBody");
            table.removeChild(oldBody[0]);
        }

        jsSort(list, sortOrderPropName);

        // Add one row (to HTML table) per element in the array.
        // Each array element has a list of properties that will become 
        // td elements (Table Data, a cell) in the HTML table. 
        var tableBody = document.createElement("tbody");
        table.appendChild(tableBody);

        // To the tbody, add one row (to HTML table) per object of the object list.
        for (var obj of objList) {
            if (isToShow(obj, filterValue)) {
                tableBody.appendChild(makeTableRow(obj, numProps1stMobileCol));
            }
        }

    } // addTableBody

    function getFirstProp(obj) {
        for (var prop in obj) {
            return prop;
        }
    }

    function makeHeader(propName, firstObjTd) {
        
        var headingCell = document.createElement("th");

        // underscores in the property name will be replaced by space in the column headings.
        var headingText = propName.replace("_", " ");

        // if the <td> for this property has a null sortOrder property, then do not add sort icon, 
        // do not add onclick to sort the table by this column.  
        if (firstObjTd.sortOrder !== null) {
            headingText = `<img src='${sortIcon}'/> ${headingText}`;
            headingCell.onclick = function () {
                console.log("WILL SORT ON " + propName);
                addTableBody(newTable, objList, propName, searchInput.value);
                forwardSort = -forwardSort; // reverses sort for next click
            };
        }
        headingCell.innerHTML = headingText;
        return headingCell;
    } //makeHeader

    function makeHeaderRow(obj, numProps1stMobileCol) {
        var headerRow = document.createElement("tr");
        headerRow.innerHTML = `
            <th class="identHeaderC mobCell">
            </th>
            <th class="infoHeaderC mobCell">
            </th>
        `;

        // These first two <th>s will be visible only in Mobile. They will hold 
        // the property names vertically (part in the 1st, the rest in the 2nd).
        var identHeader = headerRow.getElementsByClassName("identHeaderC")[0];
        var infoHeader = headerRow.getElementsByClassName("infoHeaderC")[0];

        var j = 0;
        // The rest of these headers will show only in desktop
        // iterate through the properties in the first object in the object list.

        for (let propName in obj) {

            let fldNameHdrMobile = document.createElement("p");

            if (obj[propName].sortOrder !== null) {
                fldNameHdrMobile.innerHTML = `<img src='${sortIcon}'/> ${propName}`;
                fldNameHdrMobile.onclick = function () {
                    console.log("WILL SORT ON " + propName);
                    addTableBody(newTable, objList, propName, searchInput.value);
                    forwardSort = -forwardSort; // reverses sort for next click
                };
            } else {
                fldNameHdrMobile.innerHTML = `${propName}`;
            }

            // each property name is added to one of two mobile header cells
            if (j < numProps1stMobileCol) {
                identHeader.appendChild(fldNameHdrMobile);
            } else {
                infoHeader.appendChild(fldNameHdrMobile);
            }
            j++;

            // each property name is also added to a desktop header cell.
            let headingCell = makeHeader(propName, obj[propName]);
            headingCell.classList.add("deskCell");
            headerRow.appendChild(headingCell);
        }
        return headerRow;
    } // makeHeaderRow


    // Create a container to hold the title (heading) and the HTML table
    var container = document.createElement("div");
    container.innerHTML = `<h3 style="text-align:center">${title}</h3>`;
    container.classList.add("carClickSort");

    if ((objList === undefined) || (objList[0] === undefined)) {
        var msg = "Error: MakeCarClickSortTable requires parameter property 'objList', an array with >=1 object.";
        throw msg;
        return container; // The throw above will halt execution, but just in case that gets removed... 
    }

    var headerDiv = document.createElement("div");
    headerDiv.innerHTML = "Filter by: ";
    container.appendChild(headerDiv);

    var searchInput = document.createElement("input");
    searchInput.onkeyup = function () {
        console.log("search filter changed to " + searchInput.value);
        addTableBody(newTable, objList, sortOrderPropName, searchInput.value);
    };
    headerDiv.appendChild(searchInput);

    var tableDiv = document.createElement("div");
    tableDiv.classList.add("tableDiv");
    container.appendChild(tableDiv);

    var sortOrderPropName = initialSortCol || getFirstProp(objList[0]);

    // Create a new HTML table tag (DOM object) and add that to the container.
    var newTable = document.createElement("table");
    tableDiv.appendChild(newTable);

    // To the HTML table, add a tr element to hold the headings of our table.
    // Use the first object's property names as column headings.
    var headerRow = makeHeaderRow(objList[0], numProps1stMobileCol);
    newTable.appendChild(headerRow);
     
    // After sorting objList by sortOrderPropName, create or replace the tbody 
    // populated with data from the sorted objList.
    addTableBody(newTable, objList, sortOrderPropName, searchInput.value);

    return container;

}  // MakeCarClickSortTable