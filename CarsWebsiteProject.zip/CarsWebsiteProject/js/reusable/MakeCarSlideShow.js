"use strict"; 
function MakeCarSlideShow (picList, style) {

    var slideShow = document.createElement("div");
    slideShow.classList.add(style);

    // add a div that will hold the image
   
    var slideDiv = document.createElement("div");
    slideShow.appendChild(slideDiv);
   

    // add image into the div & set the image's src attribute to show picture
    var myImage = document.createElement("img");
    slideDiv.append(myImage);

    var myCaption = document.createElement("p");
    slideDiv.append(myCaption);

    var myExtraFact = document.createElement("p");
    slideDiv.append(myExtraFact);

    var buttonDiv = document.createElement("div");
    slideShow.appendChild(buttonDiv);



    // add forward button under the image (and empty paragraph)
    var fowardButton = document.createElement("button");
    fowardButton.innerHTML = " Next ";
    slideShow.appendChild(fowardButton);


    // add back button under the image (and empty paragraph)
    var backwardButton = document.createElement("button");
    backwardButton.innerHTML = " Prev ";
    slideShow.appendChild(backwardButton);

   
    var inputBox = document.createElement("input");
    slideShow.appendChild(inputBox);

    var setSlideButton = document.createElement("button");
    setSlideButton.textContent = "Set Slide";
    slideShow.appendChild(setSlideButton);

    // add event listener to button
    setSlideButton.addEventListener("click", function () {
        // retrieve input value and convert to number
        var inputNumber = parseInt(inputBox.value);
        inputNumber = 2;
        // set slideshow picture based on input value
        if (inputNumber >= 0 && inputNumber <= picList.length) {

            pictureNumber = inputNumber; // assuming the picture number starts at 1
            setPicture();
            display();
        }
        else {
            MessageEvent("please Input valid number");
        }
    });




    // private variable that keeps track of which image is showing
    var pictureNumber = 0;
    setPicture();

    function setPicture() {
        myImage.src = picList[pictureNumber].fileName;
        
        myCaption.innerHTML = picList[pictureNumber].caption;

        myExtraFact.innerHTML = picList[pictureNumber].extrafact;
    }

    // Advance to next image in the picture list
    function nextPicture() {

        if (pictureNumber < picList.length - 1) {
            pictureNumber++;
        }
        else {
            pictureNumber = 0;
        }
        setPicture();
    }

    // Go to the previous image in picture list
    function previousPicture() {

        if (pictureNumber > 0) {
            pictureNumber--;
        }
        else {
            picList.length - 1;
        }
        setPicture();
    }


    


    // add next and previous funcionality to the buttons
    backwardButton.onclick = previousPicture;
    fowardButton.onclick = nextPicture;

    slideShow.pictureNumber = function (newNum) {
        if ((newNum >= 0) && (newNum < picList.length)) {
            pictureNumber = newNum;
            // change the src attribute of the image element to the wanted new image)				
            setPicture();
        }
    };

    return slideShow;
}