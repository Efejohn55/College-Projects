"use strict"
function carClickSortContent() {

    var carComponent = document.createElement("div");
    ajaxCarClickSort("json/cars.json", processCarData, carComponent);

   function processCarData(carList) {
        // creating a new array so we can better control what's in it, the property names (that become
        // column headings... 
        var newCarList = []; // empty array
        for (var i = 0; i < carList.length; i++) {
            newCarList[i] = {}; // set the i-th element of the new array to be an empty object.
            newCarList[i].Make = SortableCarTableUtils.makeText(carList[i].make);
            newCarList[i].Photo = SortableCarTableUtils.makeImage(carList[i].photo, "5rem");
            newCarList[i].Car_Id = SortableCarTableUtils.makeText(carList[i].id);
            newCarList[i].FirstYearIntroduced = SortableCarTableUtils.makeText(carList[i].firstyearintroduced);
            newCarList[i].Price = SortableCarTableUtils.makeNumber(carList[i].price, true); // true --> format as currency
            newCarList[i].HorsePower = SortableCarTableUtils.makeText(carList[i].horsepower);
            newCarList[i].CarOrigin = SortableCarTableUtils.makeText(carList[i].carorigin);
            newCarList[i].EngineSize = SortableCarTableUtils.makeText(carList[i].enginesize);
            newCarList[i].MaintenanceCost = SortableCarTableUtils.makeNumber(carList[i].maintenancecost, true);
        }

        carComponent.appendChild(MakeCarClickSortTable({
            title: "Car Information",
            objList: newCarList,
            initialSortCol: "Make", // if omitted, sort is by first column/property (e.g., "Make") 
            sortIcon: "icons/sortUpDown.png",
            numProps1stMobileCol: 2
        }));
    }
    //carComponent.innerHTML = content;
    return carComponent;
}