"use strict";
function carObjectComponentContent() {

    var content = ` 
      <h4>Car selection</h4>
      <p>
        Here users will be able to enter and set their desired car make/model, as well as the type of car they are looking for, such as a sport, luxury, or off-roading car for example. Users
can also input their monthly net income(take-home pay after taxes) to see how much of a car payment they can afford comfortably based off of 15 percent of their monthly net income.
      </p>
    `;

    var ele = document.createElement("div");
    
    var carsContainer = document.createElement("div");
    ele.appendChild(carsContainer);

    var carsobj1 = MakeCarsObjectComponent("Car", "type", 5000, "pics/mercedesamg.jpg");
    carsContainer.appendChild(carsobj1);

    var carsobj2 = MakeCarsObjectComponent("Car", "type", 7000, "pics/bmwm4.jpg");
    carsContainer.appendChild(carsobj2);

    var carsobj3 = MakeCarsObjectComponent("Car", "type", 6500, "pics/audirs5.jpg");
    carsContainer.appendChild(carsobj3);

    ele.innerHTML = content;
    return ele;
}