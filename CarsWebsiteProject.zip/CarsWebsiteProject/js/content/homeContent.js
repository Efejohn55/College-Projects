"use strict";
function homeContent() {

var content = `

        <h2><em><strong> Home Page About Cars! </strong> </em></h2>
        <p>
            This home page will be about cars and will talk about all different types of cars, car events, different makes, and models, as
            well as modifying cars which many
           car enthusiasts have a passion for.
        </p>

        <ul>
            <li>
                Car Make/Models
                <ul>
                    <li>
                      There are many different types of car brands and makes that people have a passion for. brands ranging from
                      JDM sport cars such as Subaru, Honda, to german cars like BMW, and Mercedes, and many more types of cars and brands,
                      like american mucsle car brands such Ford, and Chevy, and many other examples.
                    </li>
                </ul>
            </li>
            <li>
              Different Category of Cars
                <ul>
                    <li>
                      There are many different categories of cars. Sports cars aren't the only type of cars people
                      have a passion for. Some people have a passion other types of cars as
                    well such as luxury cars, off-roading cars, rally cars, and so forth
                    </li>
                </ul>
            </li>


            <li>
               Car social events
                <ul>
                    <li>
                    Another thing that is very common in the car scene is car social events. These types of social events are events where people from different
                    backgrounds and different interests in cars all meet up at a location and have what people have a "car meet" where they all meet up at a area being
                    used to host a event where many people socialize and admire and talk to others regarding other people's cars, as well as their very own car.
                    </li>
                </ul>
            </li>


            <h3> <em> Why should Users Use This Site? </em> </h3>
            <p> What users can expect to get from this website is learning about the concepts of cars and the idea of what type of cars there are, and people's passion for cars. For example, users  will be able to learn about the
  different types of car brands that are avaiable, like Mercedes, BMW, Subaru, and more.  They can learn more about the car environement and culture and the concept behind special car events
like "car meets". They can learn about the different types of cars such as sport cars, luxury cars, offroading cars, and so forth. They can also learn about
the concept of modifiying cars. Modifiying cars is a big passion that is heavily shared in the car community where many car owners modify their vehicles, by
changing aspects of their vehicles in their own desired way.</p>

<p> For example, one owner may modify their Subaru WRX(sports car) to improve their cornering capability by lowering the car with coilvers which is a aftermarket
suspesnion part. Another form of modifiying a car is a owner could modify their Toyota 4Runner(off-road/ luxury vehicle depending on the trim you buy), by getting
mud flaps, off-roading tires, and more off-roading speicifc modifcations. These are just two of the characters related to cars that owners can customize to their liking.
There are many others like interior modifications, power modifications, exterior modifications, and so forth. </p>

<p> Another aspect of my website that would motivate users to use my website is, along with describing the many concepts around cars that we see today, this
website would also include links where users could access these links to see other car brand websites where they could build their own car on the manufacterer's
website, and also include aftermarket retailer links where users can click on these links to go to aftermarket retialers for aftermarket car part modifications
For example, a user could click on a link that takes them to BMW's "M" car line up, which is BMW's sport cars. The user then on BMW's own website, can check out
the different types of cars that BMW has. Another example is having a aftermarket retailer link, like RallySportDirect for example, where when users click
on this link, it takes them to RallySportDirect's(which is a aftermarket company by the way) page, where they can look at aftermarket car parts for their specific
car make/model if rally sport direct has aftermarket parts avaiable for the users specific car make/model. This would be the general idea of this website and
what would be done to motivate users to use this website. </p>

        </ul>
 <h4> Database Table Name: Car </h4>
        <p>
            <ul>
                <LI>
                    <!--explains autoincrement feature idea to be implemented -->
                    Autoincrement: keeps track of which car brand/models are picked on website by users the most
                </LI>
            </ul>
        </p>


        <p>
            <ul>
                <LI>
                    <!--states null option 1 idea-->
                    Choose desired Car Brand: Car Brand chosen(ex. mercedes, bmw) (VARCHAR)
            </ul>
        </p>


        <p>
            <ul>
                <LI>
                    <!--states null option 2 idea -->
                    Choose desired Car Type: car type(ex. sports car, luxury car) (Decimal)
            </ul>
        </p>



        <p>
            <LH>

                3 additonal fields I will put in are:

            </LH>
        </p>



        <p>
            <ul>
                <!--3 additonal fields for the database table idea stated -->
                <li>Type of car (ex. luxury, sport etc. that user is looking for) </li>
                <li>Specific Car Part/Modification </li>
                <li>Preferred Price Range</li>
            </ul>

     <p> Image: </p>  <a target="_blank" href="pics/offroading4runner.jpg">Example of a type of car: Off Roading 4Runner</a>.
        </p>
    `;
        var ele = document.createElement("div");
        ele.innerHTML = content;
        return ele;
}