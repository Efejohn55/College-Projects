"use strict";
function carListObjectListContent() {

    var content = ` 
      <h4>Car selection</h4>
      <p>
        Here users will be able to enter and set their desired car make/model, as well as the type of car they are looking for, such as a sport, luxury, or off-roading car for example. Users
can also input their monthly net income(take-home pay after taxes) to see how much of a car payment they can afford comfortably based off of 15 percent of their monthly net income.
      </p>
    `;

    var ele = document.createElement("div");
    ele.innerHTML = content;

    var carsContainer = document.createElement("div");
    ele.appendChild(carsContainer);

    var myCarListDiv = MakeCarsListObjectListComponent([
        { name: "car", type:"select type of car", salary: 150000, imgURL: "pics/mercedesamg.jpg" },
        {},
        { name: "car", type: "select type of car", salary: 120000,  imgURL: "pics/bmwm4.jpg" },
        {},
        { name: "car", type: "select type of car", salary: 1600,  imgURL: "pics/audirs5.jpg" }

    ]);
    ele.appendChild(myCarListDiv);

    return ele;
}