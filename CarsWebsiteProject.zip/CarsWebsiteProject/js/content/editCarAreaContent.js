﻿"use strict"
function editCarAreaContent() {

    //container for entire page
    var editAreaCar = document.createElement("div");
    var content = `
        
   <h3>Edit Area content for Cars</h3>
    <p>
        Here is the edit are content for the Car Page! Here you can input in a car make, model, date the car was first announced, cost of car,
        cars horsepower, the car's yearly maintenence cost, and then you can choose out of the button options which type of car is your favorite car. You
        can also click on the drop down arrow and select which type of car modification you would choose out of the choices. Hope you enjoy the content!
    </p>

    `;
    editAreaCar.innerHTML = content;

    var carInputSpecs1 = [
        {
            "prompt": "Car Make: ",
            "fieldName": "carMake",
            "dataType": "string",
            "inputType": "text",
            "minLen": 1, // required field
            "maxLen": 9
        },
        {
            "prompt": "Car Model: ",
            "fieldName": "carModel",
            "dataType": "string",
            "inputType": "text",
            "minLen": 0, // empty string is OK
            "maxLen": 10
        },
        {
            "prompt": "date Car announced: ",
            "fieldName": "carAnnounce",
            "dataType": "date",
            "inputType": "text",
            "minLen": 0 // means optional
        },
        {
            "prompt": "Car Cost: ",
            "fieldName": "carCost",
            "dataType": "integer",
            "inputType": "text",
            "minLen": 0, // means optional
            "maxLen": 10 // 10 characters including decimal point
        },
        {
            "prompt": "HorsePower: ",
            "fieldName": "horsePower",
            "dataType": "number",
            "inputType": "text",
            "minLen": 0, // means optional
            "maxLen": 6 // 10 characters including decimal point
        },
        {
            "prompt": "Maintenance cost: ",
            "fieldName": "maintenanceCost",
            "dataType": "integer range",
            "inputType": "text",
            "minLen": 0, // means optional
            "maxLen": 7 // 10 characters including decimal point
        },
        {
            "prompt": "Pick favorite type of car out of choices:",
            "fieldName": "carChoices",
            "inputType": "select",
            "choices": ["Track Car", "Rally Car", "Super Car", "Off-Roading Car"]
        },
        {
            "prompt": "Pick favorite type of car out of choices:",
            "fieldName": "carRadioChoices",
            "inputType": "radio",
            "choices": ["Track Car", "Rally Car", "Super Car", "Off-Roading Car"]
        }
    ];
    var msgArea1 = document.createElement("div");
    var editArea1 = document.createElement("div");

    function success1(inpObj) {
        msgArea1.innerHTML = "";
        msgArea1.innerHTML += "We will process your request with these values:<br/>";
        for (var propName in inpObj) {
            msgArea1.innerHTML += "&nbsp; &nbsp; "+ propName + ": " +
                    inpObj[propName] + "<br/>";
        }
        msgArea1.innerHTML += "<br/>";
    }

    function cancel1() {
        msgArea1.innerHTML = "";
        msgArea1.innerHTML += "Sorry that you decided to cancel.<br/><br/>";
    }

    var component1 = MakeCarEditArea({
        title: "Car  Information 1",
        inputSpecs: carInputSpecs1,
        successCallBack: success1,
        cancelCallBack: cancel1
    });

    editArea1.appendChild(component1);
    editAreaCar.appendChild(editArea1);
    editAreaCar.appendChild(msgArea1);





    var carInputSpecs2 = [
        {
            "prompt": "Car Make: ",
            "fieldName": "carMake",
            "dataType": "string",
            "inputType": "text",
            "minLen": 1, // required field
            "maxLen": 9
        },
        {
            "prompt": "Car Model: ",
            "fieldName": "carModel",
            "dataType": "string",
            "inputType": "text",
            "minLen": 0, // empty string is OK
            "maxLen": 10
        },
        {
            "prompt": "date Car announced: ",
            "fieldName": "carAnnounce",
            "dataType": "date",
            "inputType": "text",
            "minLen": 0 // means optional
        },
        {
            "prompt": "Car Cost: ",
            "fieldName": "carCost",
            "dataType": "integer",
            "inputType": "text",
            "minLen": 0, // means optional
            "maxLen": 10 // 10 characters including decimal point
        },
        {
            "prompt": "HorsePower: ",
            "fieldName": "horsePower",
            "dataType": "number",
            "inputType": "text",
            "minLen": 0, // means optional
            "maxLen": 6 // 10 characters including decimal point
        },
        {
            "prompt": "Maintenance cost: ",
            "fieldName": "maintenanceCost",
            "dataType": "integer range",
            "inputType": "text",
            "minLen": 0, // means optional
            "maxLen": 7 // 10 characters including decimal point
        },
        {
            "prompt": "Pick favorite type of car out of choices:",
            "fieldName": "carChoices",
            "inputType": "select",
            "choices": ["Track Car", "Rally Car", "Super Car", "Off-Roading Car"]
        },
        {
            "prompt": "Pick favorite type of car out of choices:",
            "fieldName": "carRadioChoices",
            "inputType": "radio",
            "choices": ["Track Car", "Rally Car", "Super Car", "Off-Roading Car"]
        }
    ];

    var msgArea2 = document.createElement("div");
    var editArea2 = document.createElement("div");

    function success2(inpObj) {
        msgArea2.innerHTML = "";
        msgArea2.innerHTML += "We will process your request with these values:<br/>";
        for (var propName in inpObj) {
            msgArea2.innerHTML += "&nbsp; &nbsp; " + propName + ": " +
                inpObj[propName] + "<br/>";
        }
        msgArea2.innerHTML += "<br/>";
    }

    function cancel2() {
        msgArea2.innerHTML = "";
        msgArea2.innerHTML += "Sorry that you decided to cancel.<br/><br/>";
    }

    var component2 = MakeCarEditArea({
        title: "Car Information 2",
        inputSpecs: carInputSpecs2,
        successCallBack: success2,
        cancelCallBack: cancel2
    });

    editArea2.appendChild(component2);
    editAreaCar.appendChild(editArea2);
    editAreaCar.appendChild(msgArea2);



    return editAreaCar;
}