"use strict";
function carSlideShowContent() {

    var content = `
        <h3>My Slide Shows about Cars!</h3>
        <p> enjoy using the slideshows below! With the input text box, if you wish to use it, input in a number and the slideshow will be set to show the picture that is that number in the slideshow.
        If you enter a invalid number or a number greater than the amount of pics in the slideshow, then nothing will change </p>
    `;
    var ele = document.createElement("div");
    ele.innerHTML = content; // the HTML code specified just above...
    var twoObjects = document.createElement("div");
    twoObjects.classList.add("carSlideShow"); // see styling in this file, above...
    ele.appendChild(twoObjects);

    ajaxCarSlideShow("json/cars.json", processCarList, ele);
    function processCarList(carList) {
        for (var i = 0; i < carList.length; i++) {
            carList[i].fileName = carList[i].photo;
            console.log("image " + i + " " + carList[i].photo);
            carList[i].caption = carList[i].make;
            console.log("image " + i + " " + carList[i].make);
            carList[i].extrafact = carList[i].price;
            console.log("image " + i + " " + carList[i].price);
        }

        var ss1 = MakeCarSlideShow(carList, "slideShow");
        twoObjects.appendChild(ss1);
        ss1.setPicNum(2);
    }

    // create second slideshow object
    ajaxCarSlideShow("json/racing.json", processRacingList, ele);
    function processRacingList(raceList) {
        // MakeSlideShow expects a property called "image", so provide that...
        for (var i = 0; i < raceList.length; i++) {
            raceList[i].fileName = raceList[i].pic;
            console.log("image " + i + " " + raceList[i].pic);
            raceList[i].caption = raceList[i].racetype;
            console.log("image " + i + " " + raceList[i].racetype);
            raceList[i].extrafact = raceList[i].racefocus;
            console.log("image " + i + " " + raceList[i].racefocus);
           
        }
        var ss2 = MakeCarSlideShow(raceList, "slideShow");
        twoObjects.appendChild(ss2);
        ss2.setPicNum(2);
    }


    ajaxCarSlideShow("json/parts.json", processPartsList, ele);
    function processPartsList(partsList) {
        // MakeSlideShow expects a property called "image", so provide that...
        for (var i = 0; i < partsList.length; i++) {
            partsList[i].fileName = partsList[i].image;
            console.log("image " + i + " " + partsList[i].image);
            partsList[i].caption = partsList[i].itemName;
            console.log("image " + i + " " + partsList[i].itemName);
            partsList[i].extrafact = partsList[i].itemfocus;
            console.log("image " + i + " " + partsList[i].itemfocus);
        }
        var ss3 = MakeCarSlideShow(partsList, "slideShow");
        twoObjects.appendChild(ss3);
        ss3.setPicNum(2);
    }
        return ele;
}