function Blog() {
    return (
        <div>
            <h3>My blog </h3>
            <br/>

            <h4> My web development experience </h4>
            <p>My web development experience isn't too much so far. I just started getting more into web development this semester in my cilent side scripting course.
                I took a web design course in my last year of community college, although I didnt learn too much and havent done any web design for a while. Now I am picking back up on
                learning and improving my web design skills by gaining practice and learning new things through the homework and lab assignments I am doing. For example,
                in this homework/lab assignment, I am gaining experience learning how to create tabs and drop down menus in the navigation bar, as well as working
                with javascript files for the first time. </p>
            <br/>

            <h4> Home page homework </h4>
            <p> What I found valuable and learned from my very first homework assignment, is working and creating my website using
                different types of tools like changing the fonts of the text or adding an image in my website and overall
                just gaining more experience in creating and working on a website. Some things I changed around are I tried
                to make everything blend in well, as well as I made the navigation bar blend in well with the background image and made
                the text clear and visible. Other things I did was, I made sure the navigation bar and the footer were both in fixed positions
                where they wouldn't move regardless of scrolling up and down on the web page. Some things that I have done were I changed the font up on the text
                in the body, and changed the font of the title page to make it stand out differently from the texts. After that, what else I did is I changed up some
                of the padding in the navigation bar and the footor for example, as well as adding a fixed background image. What I found easy was
                being able to do simple things like change or add padding to the navigation bar, and footer, or being able to add a background image, although it
                was confusing to add a background image at first, I was able to figure out how to add one. What I found difficult however when doing my first homework assignment, was how to be able to
                create a external style sheet to implement for my website, and also trying to figure out how to add a external stylesheet link on my html page. These are the things I learned and
                found easy or difficult in my first homework assignment which was the Home page Homework.
            </p>
            <br/>

            <h4> JU UI Design </h4>
            <p> What I found easy for my second homework assignment is being able to add additonal java script files, like the info javascript
                , and being able to make simple changes, like changing the colors, fonts of the words in the nav bar, and whatnot. WHat I found hard was trying to add in
                the info link and tab at first. In the lab 2 assignment, when I first tried adding the info tab in the navigation bar, the tab wouldn't load up
                correctly and it would keep presenting the page blank when I would try to run the webpage. What I found out the problem was is there was a
                "," missing after entering the info content link code in the code program so when I would run the website it wouldn't load up the website properly.
                Once I fixed that it fixed the issue. What I found valuable about this lab 2 is learning about how to create and link a multitude of pages together so
                they can all work together. For example if you are on the main index page, and click on the 7th link which takes you to the index page in folder 11, from
                there you are on the home page and in the navigation bar, you check out the blog tab, or info tab and see the additonal web pages that you can access through
                those  tabs in the navigation bar. This allows there to be a bunch of webpages all connected together simultaneously, where you can hop from
                webpage to webpage, and view different webpages. </p>
            <br/>

            <h4> Module 3: JS objects  </h4>
            <p>   In this homework assignment, in module 3 which was about javascript objects, what I found easy was making simple changes like creating the
                necessary javascript files needed for my website like, carContent, MakeCarsParamList, and so forth. What I found difficult was trying to get and
                implement a destructuring object to work in the "my objects" page under the search tab where I have to link the "search Objects" page with
                the generating content. I was struggling to figure out how to get that to work and what code I need to create for it to work. What I found valuable
                in this module is adding in the destructure parameter objects and creating our own objects that we made for our website. Another valuable thing
                is learning more about the design specifications in step 10 of the HW assignment where we have to make specific code design specifications to
                more so customize our website even further. </p>
            <br/>

            <h4>   Module 4: Object List Component </h4>
            <p>  In this homework assignment, in module 4 which was about Object List Component,  what I found easy in this homework assignment was adding in the required parameter and destructured parameter objects into the code. I believed adding those
                segments code into my homework assignment was pretty straightfoward for the most part, and wasn't too difficult. What I found difficult was trying to add
                in a array of objects. This was tough for me because although I did add an array for one of my properties, my images in my
                content generating function page would not load, and I couldn't figure it out. Therefore, the array of objects part for me, was the hard part of this
                homework assignment. What I found valuable is gaining more experience with working with input parameter and destructured parameter objects. I think its good how
                we get experience working with both input parameter, and destructured parameter objects, as both types have their own special benefit in html coding. </p>
            <br/>

            <h4>  Module 5: JS Slide Show(Introduces AJAX) </h4>
            <p>   In this homework assignment, module 5 which was about slide shows, and introduced the concept of AjAX, what I found easy in this homework assignment was being able
                to add in new images into the JSON files to make them more suited towards the topic of my webpage which is about cars. For example, instead of having three slide shows of
                cats, cars(normal cars, not suited towards focus of my webpage), and jet skies and such, I changed the theme of the slide shows to  one of them showing different types of
                sport car models, like a Audi R8, BMW M5, showing their prices alongside the caption, and so forth. Similiar to the original default "cars" JSON file that we were supplied with, but added more high end cars, and focused
                more on having sport cars and super cars, then just a mix of sport cars and everyday normal cars. One of my other slides shows the different types of racing such as drag racing,
                rally racing, etc. Then my final third slide shows different types of car parts and their area of focus. This is what I changed the 3 slides to. Made it more focused around my
                webpage idea. Therefore this is what I found pretty straight foward and easy to. What I found difficult to do at first was trying to implement the JSON files in with the nav router
                and the other files. In the sample code in folder 15, in the oringal slideshowcontent js file, I had to find a way to be able to implement the JSON files through AJAX, since the default
                slide shows were implemented manually by listing each indivbidual image in the araay. I had to create a loop that would loop through all the images in the JSON files instead. Therefore,
                that was a bit tough at first to figure out, but I managed to figure it out and get it to work with AJAX and with the JSON files implemented in the code. What I found valuable about this
                homework assignment was gaining more experience with working with AJAX. I liked how we created a for loop where the code would cycle through the JSON files that contained a bunch of images,
                along with different things about the images. For example in my cars JSON file, you have pictures of the cars but also other headings like the price of the car, the name of the car,
                and so forth. Also gaining more exposure with working with the JSON files and seeing how those type of files worked was also very nice to experience. I liked how the files could store
                a number of images as well as other headings in each image category. Overall I enjoyed doing this homework for module 5.
            </p >
            <br />

            <h4> Module 6: JS Click Sort(Uses AJAX) </h4>
            <p> In this homework assignment for module 6 which was about using and working with click sort events and table filters using ajax files and whatnot, what I found easy in this homework
                is being able to implement in the ajax files as well as being able to implement in the ajax code into the files that I needed to make a change to and edit. I believe this task wasn't too difficult
                of a task to acheive. At first it was a bit hard, trying to implement the AJAX code into the javascript code, as there were some error issues that popped up here and there that causing issues for the code
                to work properly. However, I was able to get the AJAX code all working correctly in regards to AJAX in the javascript code. I was able to do this in a decent amount of time which was not too bad. What I found
                difficult was the issue that I had with implementing in the clicksort and filter table code in each of the javadcript files that I needed to implement them into. I was able to implement both
                the clicksort and make filter code into my content files. However, I had this issue where if you would click on one of the click sort events, it would take away the filter where you could search for
                the specific items and categories in the table. The only way you could bring the search filter back is by refreshing the page. That was a bit of an issue for me to deal with as I found it difficult to
                figure out what was wrong with the code. What I found valuable in this assignment was working with clicksort and the make filter table code for the first time. I like how through the clicksort,
                just through the click of a button, you can simply change the order of which objects are displayed and those objects show in a speicifc order depending on the code that does the sorting of the order of the
                items. I also really like the filter table search code. Being able to search for specific results where the table shows the top results that are closest to your search that you inputted in is very convient way
                of being able to search for items in the table. This also makes interacting with the table more effective, as users can search for what they are looking for more efficently rather than just scrolling through the
                entire table trying to find the item they are looking for which could be time consuming depending on how big the table is. With the search filter, the item, if it is written in the table to begin with, will
                pop up right at the top of the table when the user searches for that specific item or category they are looking for.  </p>
            <br/>

            <h4>  Module 7: React  </h4>
            <p>   In this homework assignment for module 7: react, what I found easy was being able to use the sample code as a reference for one of my JSON files as one of the default JSON files which was
                about cars, can be used for the theme of my webpage which is about cars, so I was able to use that sample code as a reference, and changed up the code in that file and added cars of my own choosing in that
                sample code. What I found difficult was trying to use the sample code where it has a search bar for one of the JSON files, with my other JSON file. My other JSON file is about car parts and I was trying to replicate
                the users table code where I would have aftermarket car part modifications listed and the user would be able to search up the specific part they desire and/or are looking for. Getting that to work however was pretty difficult as I had to
                really change around a good amount of things when I used the sample code as a reference as user info and car parts are completely different topics and have different sub categories. What I found valuable was how the code created tables in a organized fashion
                to display everything and I also liked the search feature for one of the JSON files as well. I like how the user can search for a specific item they are looking for, for example, and it will pop up with a image representation of the item, as well as the name of the item,
                and the price, and so forth. </p>
            <br/>

            <h4> Module 8: Input Component with Callback </h4>
            <p>  This homework assignment for module 8 dealt with the callback function. The task I found easy in this homework was adding all the things together initially
                on a sample code to have everything on the same page. For example, I had the radio buttons, two make edit area fucntions, and the select list all on one page and it wasnt too difficult
                to put them on one page. Another easy thing was linking the page through the nav router. The difficult part was putting all the requirements in a javascript function page
                and trying to get it to run well. I struggled for a good amount and was not able to figure it out as my edit area javascript page does not load the functions properly. However eventually
                now I got everything to be able to work properly but it was difficult for me to figure it out at first. What I found valueable about this assignment is working with callback functions. I thought they were enjoyable to work with.
                Overall I thought the callback functions in this module were a nice function to work with, and experience. I would say its definetly one of my favorite modules to work with.</p>

        </div>
    );
}