const PartsTable = ({list}) => {
    
    console.log("PartsTable invoked");
    return (
        <div className="clickSort"> 

            <table>
                <thead>
                    <tr>
                        <th>Name of Aftermarket car part</th>
                        <th className="textAlignCenter">Image</th>
                        <th className="textAlignRight">estimated price</th>
                        <th className="textAlignLeft">Purpose of Item</th>
                        <th className="textAlignLeft">Choose Item if:</th>
                        <th className="textAlignLeft">Some Popular Car Parts</th>
                      
                        
                    </tr>
                </thead>
                <tbody>
                    {
                        list.map(listObj =>
                            <tr key={listObj.webPartsId}>
                                <td>{listObj.itemName}</td>
                                <td className="shadowImage textAlignCenter"><img src={listObj.image} /></td>
                                <td className="textAlignRight">{listObj.price}</td>
                                <td className="textAlignLeft">{listObj.itemfocus}</td>
                                <td className="textAlignLeft">{listObj.idealfor}</td>
                                <td className="textAlignLeft">{listObj.wellknownparts}</td>
                                
                                
                               
                            </tr>
                        )
                    } 
                </tbody>
            </table>
        </div>
    );
};

