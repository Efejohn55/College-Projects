﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderingSystem
{
    public class GlobalData
    {
        public static MenuManagementSystem MenuOrderingSystem = new MenuManagementSystem();
        public const double SALES_TAX = 0.08;
    }
}
