﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace OrderingSystem
{
    public class orderDatabase
    {
        OleDbConnection myConnection;
        DataSet orderDataSet;
        OleDbDataAdapter myDataAdapter;
        OleDbCommand orderCommand;
        string orderSQL;

        public orderDatabase()
        {

        }

       public void addOrdertoDatabase(Order order)
        {
            myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=OrderingSystem.accdb");
            myConnection.Open();
            orderSQL = "INSERT INTO [Order] (OrderNumber, TableNumber, OrderTime, Cost) VALUES (" + order.OrderNumber + ", '" + order.TableNumber + "', #" + order.OrderDateTime + "#, " + order.Cost + ")";
            orderCommand = new OleDbCommand(orderSQL, myConnection);
            orderDataSet = new DataSet("userTable");
            orderCommand.ExecuteNonQuery();
            myConnection.Close();
        }


        public static void loadOrdersFromDatabase(ListView listView)
        {
            OleDbConnection myConnection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=OrderingSystem.accdb");
            myConnection.Open();
            string ordersSQL = "SELECT * FROM [Order]";
            OleDbDataAdapter myDataAdapter = new OleDbDataAdapter(ordersSQL, myConnection);
            DataTable orderDataSet = new DataTable();
            myDataAdapter.Fill(orderDataSet);
            myConnection.Close();

            
            listView.Items.Clear();

          
            listView.Columns.Add("Order #");
            listView.Columns.Add("Table #");
            listView.Columns.Add("Order Time");
            listView.Columns.Add("Cost");

           
            foreach (DataRow row in orderDataSet.Rows)
            {
                ListViewItem listViewItem = new ListViewItem(row["OrderNumber"].ToString());
                listViewItem.SubItems.Add(row["TableNumber"].ToString());
                listViewItem.SubItems.Add(row["OrderTime"].ToString());
                listViewItem.SubItems.Add(row["Cost"].ToString());
                listView.Items.Add(listViewItem);
            }
        }


    }
}
