﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderingSystem;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderingSystem.Tests
{
    [TestClass()]
    public class accountUsersDatabaseTests
    {
        string accountUserName = "Amy";
        string accountPassword = "word";
        string accountUserType = "Manager";

        accountUsersDatabase userData = new accountUsersDatabase();
        
        [TestMethod()]
        public void accountUsersDatabaseTest()
        {
           
        }

        [TestMethod()]
        public void TestCheckUserCredentials()
        {

            bool expected = true;
            bool expected2 = false;
            bool actual = accountUsersDatabase.checkUserCredientals(accountUserName, accountPassword, accountUserType);

            // Assert
            Assert.AreEqual(expected, actual);
            Assert.AreNotEqual(expected2, actual);
        }

        [TestMethod()]
        public void addUserToExcelTest()
        {
            accountUsers validUser = new accountUsers()
            {
                AccountUserName = "TestUser1",
                AccountUserPassword = "TestPassword1",
                AccountUserType = "TestType1"
            };
            userData.addUserToExcel(validUser);
            OleDbConnection excelConnection1 = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=AccountUsers.xlsx;Extended Properties=Excel 12.0");
            excelConnection1.Open();
            OleDbCommand excelCommand1 = new OleDbCommand("SELECT COUNT(*) FROM AccountUsers WHERE AccountUserName = 'TestUser1'", excelConnection1);
            int numRows1 = (int)excelCommand1.ExecuteScalar();
            excelConnection1.Close();
            Assert.AreEqual(1, numRows1);

        }

       
    }
}