﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderingSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;


namespace OrderingSystem.Tests
{
    [TestClass()]
    public class menuItemDatabaseTests
    {
        menuItemDatabase itemData = new menuItemDatabase();
        OleDbConnection connection = new OleDbConnection();
        OleDbCommand command = new OleDbCommand();

        [TestMethod()]
        public void menuItemDatabaseTest()
        {
            Assert.Fail();
        }

        [TestMethod()]
        public void addItemToMenuDatabaseTest()
        {
            MenuItem item = new MenuItem("Test Item", 10.99, MenuCategory.Entree);
            item.Calories = 500;
            item.Carbs = 50;
            item.Fats = 20;
            item.Proteins = 30;
            item.SodiumContent = 800;
            item.Ingredients = "Test Ingredients";
            item.AllergyInfo = "Test Allergy Info";
             
            MenuCategory cat = MenuCategory.Entree;

            string result = itemData.addItemToMenuDatabase(item, cat);

            Assert.AreEqual("added item", result);
        }

        [TestMethod()]
        public void removeItemFromMenuDatabaseTest()
        {
            MenuManagementSystem menu = new MenuManagementSystem();
            List<MenuItem> Menu = new List<MenuItem>();

            MenuItem item1 = new MenuItem("Mozzarella Sticks", 7.99, MenuCategory.Appetizer);
            MenuItem item2 = new MenuItem("Steak", 19.99, MenuCategory.Entree);
            MenuItem item3 = new MenuItem("Soda", 1.99, MenuCategory.Drink);
            menu.AddToMenu(item1);
            menu.AddToMenu(item2);
            menu.AddToMenu(item3);

            bool result = menu.RemoveFromMenu(item2);
            Assert.IsTrue(result);
            Assert.AreEqual(2, menu.GetMenu().Count);
            Assert.AreNotEqual(6, menu.GetMenu().Count);

            MenuItem item4 = new MenuItem("Ice Cream", 4.99, MenuCategory.Dessert);
            result = menu.RemoveFromMenu(item4);
            Assert.IsFalse(result);
            Assert.AreEqual(3, menu.GetMenu().Count);

            result = menu.RemoveFromMenu(new MenuItem("Soda", 1.99, MenuCategory.Drink));
            Assert.IsTrue(result);
            Assert.AreEqual(2, menu.GetMenu().Count);

        }

        [TestMethod()]
        public void loadFromMenuItemDatabaseTest()
        {
            int expectedRowCount = 5; 

            DataTable actualResult =  menuItemDatabase.loadFromMenuItemDatabase();

            Assert.IsNotNull(actualResult);
            Assert.AreEqual(expectedRowCount, actualResult.Rows.Count);
        }

        [TestMethod()]
        public void LoadMenuItemCategoryToMenuTest()
        {
            MenuCategory category = MenuCategory.Appetizer;
            ListView list = new ListView();
            itemData.LoadMenuItemCategoryToMenu(category, list);
            Assert.IsTrue(list.Items.Count >= 0);
            Assert.IsFalse(list.Items.Count < 0);

         
        }

        [TestMethod()]
        public void AddAllToDatabaseTest()
        {
            DataGridView dataGrid = new DataGridView();
            dataGrid.Columns.Add("Category", "Dessert");
            dataGrid.Columns.Add("Description", "Choclate Cake");
            dataGrid.Columns.Add("Price", "12.50");
            dataGrid.Columns.Add("Calories", "800");
            dataGrid.Columns.Add("Carbs", "200");
            dataGrid.Columns.Add("Fats", "300");
            dataGrid.Columns.Add("Proteins", "50");
            dataGrid.Columns.Add("SodiumContent", "300");
            dataGrid.Columns.Add("Ingredients", "eggs,flower");
            dataGrid.Columns.Add("AllergyInformation", "eggs");

            // add test data
            dataGrid.Rows.Add("Dessert", "Choclate Cake", "12.50", 800, 200, 300, 50, 300, "eggs,flower", "eggs");
            dataGrid.Rows.Add("Drinks", "Pepsi", "8.00", 300, 150, 70.50, 10, 190, "Sugar", "none");

            itemData.AddAllToDatabase(dataGrid);

             connection = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=OrderingSystem.accdb");
            connection.Open();
             command = new OleDbCommand("SELECT COUNT(*) FROM menuItem", connection);
            int count = (int)command.ExecuteScalar();
            connection.Close();

            Assert.AreEqual(2, count);
            Assert.AreNotEqual(5, count);

        }


        [TestMethod()]
        public void DeleteMenuItemTest()
        {
            List<MenuItem> menu = new List<MenuItem>();
            menu.Add(new MenuItem("Item 1", 10.0, MenuCategory.None));
            menu.Add(new MenuItem("Item 2", 15.0, MenuCategory.Dessert));
            menu.Add(new MenuItem("Item 3", 20.0, MenuCategory.Drink));

            int startMenuSize = 3;

            // Create selected test vars
            ListView.SelectedListViewItemCollection selectedItems = new ListView.SelectedListViewItemCollection(null);
            ListViewItem selectedItem = new ListViewItem("Item 2");
            selectedItem.SubItems.Add("15.0");
            //selectedItems.Add(selectedItem);

            // Call the DeleteMenuItem method
            MenuManagementSystem.DeleteMenuItem(selectedItems, MenuCategory.Dessert);

            // Check that the item was removed from the menu by count
            Assert.AreEqual(2, menu.Count);
            Assert.AreNotEqual(startMenuSize, menu.Count);

            // checks that the item, or part of the obj doesnt exist in list
            Assert.IsFalse(menu.Any(item => item.Description == "Item 2" && item.Price == 15.0 && item.Category == MenuCategory.Dessert));
        }
    }
}