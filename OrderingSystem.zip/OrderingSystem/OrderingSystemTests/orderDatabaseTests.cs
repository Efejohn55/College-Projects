﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OrderingSystem;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace OrderingSystem.Tests
{
    [TestClass()]
    public class orderDatabaseTests
    {
        
        
        [TestMethod()]
        public void addOrdertoDatabaseTest()
        {
            Order testOrder = new Order();

            ulong OrderNumber = 3456;
            string TableNumber = "table 1";
            DateTime date = DateTime.Now;
            double cost = 23.45;

            OrderNumber = testOrder.OrderNumber;
            TableNumber = testOrder.TableNumber;
            date = testOrder.OrderDateTime;
            cost = testOrder.Cost;
              
           // orderDatabase orderData = new orderDatabase();

            //orderData.addOrdertoDatabase(testOrder);

            Order order2 = new Order();

            order2.OrderNumber = 3452;
            order2.TableNumber = "table 2";

            Assert.AreEqual(testOrder.OrderNumber, order2.OrderNumber);
            Assert.AreNotEqual(testOrder.TableNumber, order2.TableNumber);

        }

        public void loadOrdersFromDatabase()
        {
            ListView listView = new ListView();
            //orderDatabase.loadOrdersFromDatabase(listView);

            // Assert that the ListView contains at least one item
            Assert.IsTrue(listView.Items.Count > 0);
            Assert.IsFalse(listView.Items.Count < 0);
        }
    }
}