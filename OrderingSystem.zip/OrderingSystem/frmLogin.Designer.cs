﻿
namespace OrderingSystem
{
    partial class frmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmLogin));
            this.txtUsername = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.usernameIbl = new System.Windows.Forms.Label();
            this.passwordIbl = new System.Windows.Forms.Label();
            this.userTypeIbl = new System.Windows.Forms.Label();
            this.orIbl = new System.Windows.Forms.Label();
            this.btnRegister = new System.Windows.Forms.Button();
            this.comboUserType = new System.Windows.Forms.ComboBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.welcomeIbl = new System.Windows.Forms.Label();
            this.accountInfosIbl = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txtUsername
            // 
            this.txtUsername.Location = new System.Drawing.Point(522, 304);
            this.txtUsername.Name = "txtUsername";
            this.txtUsername.Size = new System.Drawing.Size(100, 22);
            this.txtUsername.TabIndex = 0;
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(522, 344);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(100, 22);
            this.txtPassword.TabIndex = 1;
            // 
            // btnLogin
            // 
            this.btnLogin.Location = new System.Drawing.Point(522, 442);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(100, 33);
            this.btnLogin.TabIndex = 3;
            this.btnLogin.Text = "Login";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click);
            // 
            // usernameIbl
            // 
            this.usernameIbl.AutoSize = true;
            this.usernameIbl.Location = new System.Drawing.Point(401, 304);
            this.usernameIbl.Name = "usernameIbl";
            this.usernameIbl.Size = new System.Drawing.Size(107, 16);
            this.usernameIbl.TabIndex = 4;
            this.usernameIbl.Text = "Enter Username:";
            // 
            // passwordIbl
            // 
            this.passwordIbl.AutoSize = true;
            this.passwordIbl.Location = new System.Drawing.Point(406, 344);
            this.passwordIbl.Name = "passwordIbl";
            this.passwordIbl.Size = new System.Drawing.Size(103, 16);
            this.passwordIbl.TabIndex = 5;
            this.passwordIbl.Text = "Enter password:";
            // 
            // userTypeIbl
            // 
            this.userTypeIbl.AutoSize = true;
            this.userTypeIbl.Location = new System.Drawing.Point(391, 397);
            this.userTypeIbl.Name = "userTypeIbl";
            this.userTypeIbl.Size = new System.Drawing.Size(108, 16);
            this.userTypeIbl.TabIndex = 6;
            this.userTypeIbl.Text = "Enter User Type:";
            // 
            // orIbl
            // 
            this.orIbl.AutoSize = true;
            this.orIbl.Location = new System.Drawing.Point(556, 478);
            this.orIbl.Name = "orIbl";
            this.orIbl.Size = new System.Drawing.Size(27, 16);
            this.orIbl.TabIndex = 7;
            this.orIbl.Text = "OR";
            // 
            // btnRegister
            // 
            this.btnRegister.Location = new System.Drawing.Point(522, 498);
            this.btnRegister.Name = "btnRegister";
            this.btnRegister.Size = new System.Drawing.Size(100, 38);
            this.btnRegister.TabIndex = 8;
            this.btnRegister.Text = "Register";
            this.btnRegister.UseVisualStyleBackColor = true;
            this.btnRegister.Click += new System.EventHandler(this.btnRegister_Click);
            // 
            // comboUserType
            // 
            this.comboUserType.FormattingEnabled = true;
            this.comboUserType.Items.AddRange(new object[] {
            "Manager",
            "Server",
            "Kitchen Staff"});
            this.comboUserType.Location = new System.Drawing.Point(522, 394);
            this.comboUserType.Name = "comboUserType";
            this.comboUserType.Size = new System.Drawing.Size(121, 24);
            this.comboUserType.TabIndex = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::OrderingSystem.Properties.Resources.Chilis500X320;
            this.pictureBox1.Location = new System.Drawing.Point(325, 69);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(491, 186);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 11;
            this.pictureBox1.TabStop = false;
            // 
            // welcomeIbl
            // 
            this.welcomeIbl.AutoSize = true;
            this.welcomeIbl.Location = new System.Drawing.Point(406, 35);
            this.welcomeIbl.Name = "welcomeIbl";
            this.welcomeIbl.Size = new System.Drawing.Size(295, 16);
            this.welcomeIbl.TabIndex = 12;
            this.welcomeIbl.Text = "Welcome! Please login or register for an account";
            // 
            // accountInfosIbl
            // 
            this.accountInfosIbl.AutoSize = true;
            this.accountInfosIbl.Location = new System.Drawing.Point(12, 257);
            this.accountInfosIbl.Name = "accountInfosIbl";
            this.accountInfosIbl.Size = new System.Drawing.Size(278, 288);
            this.accountInfosIbl.TabIndex = 13;
            this.accountInfosIbl.Text = resources.GetString("accountInfosIbl.Text");
            // 
            // frmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1118, 603);
            this.Controls.Add(this.accountInfosIbl);
            this.Controls.Add(this.welcomeIbl);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.comboUserType);
            this.Controls.Add(this.btnRegister);
            this.Controls.Add(this.orIbl);
            this.Controls.Add(this.userTypeIbl);
            this.Controls.Add(this.passwordIbl);
            this.Controls.Add(this.usernameIbl);
            this.Controls.Add(this.btnLogin);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtUsername);
            this.Name = "frmLogin";
            this.Text = "frmLogin";
            this.Load += new System.EventHandler(this.frmLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtUsername;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnLogin;
        private System.Windows.Forms.Label usernameIbl;
        private System.Windows.Forms.Label passwordIbl;
        private System.Windows.Forms.Label userTypeIbl;
        private System.Windows.Forms.Label orIbl;
        private System.Windows.Forms.Button btnRegister;
        private System.Windows.Forms.ComboBox comboUserType;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label welcomeIbl;
        private System.Windows.Forms.Label accountInfosIbl;
    }
}